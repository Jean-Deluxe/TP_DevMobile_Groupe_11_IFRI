package com.example.e_vote

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
