import 'package:e_vote/detail.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:e_vote/detail.dart';

class VCours extends StatefulWidget {
  const VCours({Key? key}) : super(key: key);

  @override
  State<VCours> createState() => _VCoursState();
}

class _VCoursState extends State<VCours> {
  bool isEnabled = true;
  bool term = false;
  int selectedIndex = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        //possss
        padding: const EdgeInsets.symmetric(vertical: 80),
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topRight,
            end: Alignment.bottomLeft,
            colors: [
              Colors.white,
              Color(0xFF2D48ED),
            ],
          ),
        ),
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  IconButton(
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                      icon: const Icon(
                        Icons.arrow_back_rounded,
                        color: Colors.black,
                      )),
                  Expanded(
                    child: Center(
                        child: Container(
                      margin: const EdgeInsets.only(right: 30),
                      child: const Text(
                        "Vote en cours",
                        style: TextStyle(
                            fontSize: 30,
                            fontWeight: FontWeight.bold,
                            color: Colors.black),
                      ),
                    )),
                  )
                ],
              ),
              const SizedBox(height: 50),
              Container(
                padding: const EdgeInsets.all(10),
                margin: const EdgeInsets.symmetric(horizontal: 30),
                height: MediaQuery.of(context).size.height * 0.2,
                width: MediaQuery.of(context).size.width * 0.8,
                decoration: BoxDecoration(
                  color: Colors.white30,
                  boxShadow: const [
                    BoxShadow(
                        color: Colors.black12,
                        offset: Offset(0, 5),
                        blurRadius: 5,
                        spreadRadius: 3)
                  ],
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Center(
                    child: Column(
                  children: [
                    const Text(
                      'Bureau des étudiants',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(
                      height: 5,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Column(
                          children: [
                            Switch(
                                inactiveTrackColor: Colors.white24,
                                activeColor: Colors.white24,
                                activeTrackColor:
                                    const Color.fromARGB(255, 25, 122, 27),
                                value: isEnabled,
                                onChanged: (bool value) {
                                  setState(() {
                                    isEnabled = value;
                                  });
                                }),
                            const SizedBox(
                              height: 1,
                            ),
                            const Text(
                              "En cours",
                              style: TextStyle(fontSize: 15),
                            )
                          ],
                        ),
                        const SizedBox(
                          width: 30,
                        ),
                        Container(
                          width: 150,
                          height: 40,
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              shadowColor: Color.fromARGB(255, 73, 12, 12),
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10)),
                              //ombreshadowColor: Colors.blue[900],
                              primary: Colors.blue[900],
                              elevation: 10,
                            ),
                            onPressed: () {
                              Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (ctx) {
                                    return const Detail();
                                  },
                                ),
                              );
                            },
                            child: const Text(
                              "Détails",
                              style: TextStyle(color: Colors.white),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                )),
              ),
              const SizedBox(height: 50),
              Container(
                padding: const EdgeInsets.all(10),
                margin: const EdgeInsets.symmetric(horizontal: 30),
                height: MediaQuery.of(context).size.height * 0.2,
                width: MediaQuery.of(context).size.width * 0.8,
                decoration: BoxDecoration(
                  color: Colors.white30,
                  boxShadow: const [
                    BoxShadow(
                        color: Colors.black12,
                        offset: Offset(0, 5),
                        blurRadius: 5,
                        spreadRadius: 3)
                  ],
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Center(
                    child: Column(
                  children: [
                    const Text(
                      'Bureau des étudiants',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(
                      height: 5,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Column(
                          children: [
                            Switch(
                                activeColor: Colors.white24,
                                inactiveThumbColor: Colors.white24,
                                inactiveTrackColor:
                                    const Color.fromARGB(255, 170, 55, 55),
                                value: term,
                                onChanged: (bool value) {
                                  setState(() {
                                    term = value;
                                  });
                                }),
                            const SizedBox(
                              height: 1,
                            ),
                            const Text(
                              "Terminé",
                              style: const TextStyle(fontSize: 15),
                            )
                          ],
                        ),
                        const SizedBox(
                          width: 30,
                        ),
                        Container(
                          width: 150,
                          height: 40,
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                                shadowColor: Color.fromARGB(255, 73, 12, 12),
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10)),
                                //ombreshadowColor: Colors.blue[900],
                                primary: Colors.blue[900],
                                elevation: 10),
                            onPressed: () {
                              Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (ctx) {
                                    return const Detail();
                                  },
                                ),
                              );
                            },
                            child: const Text(
                              "Détails",
                              style: TextStyle(color: Colors.white),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                )),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        elevation: 20,
        backgroundColor: const Color.fromARGB(255, 189, 197, 202),
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(
              Icons.copy_all_outlined,
              //color: Colors.black,
              size: 40,
            ),
            label: "Dossiers",
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.add_circle_outlined,
              //color: Colors.black,
              size: 40,
            ),
            label: "Ajouter",
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.person,
              //color: Colors.black,
              size: 40,
            ),
            label: "Profil",
          )
        ],
        currentIndex: selectedIndex,
        selectedItemColor: const Color(0xFF2D48ED),
        onTap: (int index) {
          setState(() {
            selectedIndex = index;
          });
        },
      ),
    );
  }
}
