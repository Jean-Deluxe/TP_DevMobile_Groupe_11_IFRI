import 'package:e_vote/acceuil.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'main.dart';

class Attent extends StatefulWidget {
  const Attent({Key? key}) : super(key: key);

  @override
  State<Attent> createState() => _AttentState();
}

class _AttentState extends State<Attent> {
  String message = "";
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    msg();
  }

  String msg() {
    var _msg = "";
    SharedPreferences.getInstance().then((value) {
      _msg = "Désolé ce vote commence le ${value.getString("begin")}";
      message = _msg;
      setState(() {});
    });
    return _msg;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Veuillez patienter",
          style: TextStyle(
              color: Color(0xFF2F80F7),
              fontSize: 30,
              fontWeight: FontWeight.bold),
          textAlign: TextAlign.center,
        ),
        centerTitle: true,
        backgroundColor: const Color(0xFFE4E8E9),
        foregroundColor: Color(0xFF2F80F7),
        elevation: 0,
      ),
      body: Container(
          height: MediaQuery.of(context).size.height,
          color: const Color(0xFFE4E8E9),
          padding: const EdgeInsets.all(20),
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Center(
                    child: Padding(
                  padding: const EdgeInsets.all(15.0),
                  child: ClipOval(
                    child: Image.asset(
                      "assets/attent.png",
                      width: 100,
                      height: 100,
                    ),
                  ),
                )),
                Padding(
                  padding: const EdgeInsets.all(20.0).copyWith(top: 20),
                  child: Text(
                    message,
                    style: const TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                        fontSize: 20),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 15)
                      .copyWith(top: 75),
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (ctx) {
                            return const Acceuil();
                          },
                        ),
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(horizontal: 35),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30.0),
                      ),
                      primary: const Color(0xFF2F80F7),
                    ),
                    child: const Text(
                      "Terminé",
                      style: TextStyle(fontSize: 16),
                    ),
                  ),
                ),
              ],
            ),
          )),
    );
  }
}
