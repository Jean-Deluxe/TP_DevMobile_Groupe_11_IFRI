import 'package:e_vote/acceuil.dart';
import 'package:e_vote/dashbord.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';

class Chargement extends StatefulWidget {
  const Chargement({Key? key}) : super(key: key);

  @override
  State<Chargement> createState() => _ChargementState();
}

class _ChargementState extends State<Chargement>
    with SingleTickerProviderStateMixin {
  AnimationController? _controller;
  Animation<double>? _animation;
  int i = 0;

  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(seconds: 8), () {
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: ((context) => const Acceuil())));
      print("hello");
    });
    _controller = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 5000));
    _animation = Tween<double>(begin: 0, end: 1).animate(_controller!);
    _controller!.addListener(() {
      setState(() {});
    });
    _controller!.repeat();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: Colors.white,
        padding: EdgeInsets.symmetric(vertical: 115),
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        child: Column(children: [
          Image.asset(
            "assets/voter.png",
            height: MediaQuery.of(context).size.height * 0.3,
            width: MediaQuery.of(context).size.width * 0.3,
            alignment: Alignment.center,
          ),
          SizedBox(
            height: 200,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _buildLoadingCircle(0),
              SizedBox(height: 20),
              _buildLoadingCircle(0.2),
              SizedBox(height: 20),
              _buildLoadingCircle(0.4),
              SizedBox(height: 20),
              _buildLoadingCircle(0.6),
              SizedBox(height: 20),
              _buildLoadingCircle(0.8),
              SizedBox(height: 20),
            ],
          ),
        ]),
      ),
    );
  }

  Widget _buildLoadingCircle(double delay) {
    return Container(
      width: 15,
      height: 10,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: _animation!.value > delay
            ? Colors.blue
            : Colors.blue.withOpacity(0.2),
      ),
    );
  }

  @override
  void dispose() {
    _controller!.dispose();
    super.dispose();
  }
}
  //premiere page