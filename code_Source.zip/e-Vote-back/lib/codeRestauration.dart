import 'dart:ui';

import 'package:e_vote/fileBack/genererCode.dart';
import 'package:e_vote/fileBack/mailRecuperation.dart';
import 'package:e_vote/restaurerPassword.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:e_vote/connexion.dart';
import 'package:shared_preferences/shared_preferences.dart';

class CodeRestauration extends StatefulWidget {
  const CodeRestauration({Key? key}) : super(key: key);

  @override
  State<CodeRestauration> createState() => _CodeRestaurationState();
}

class _CodeRestaurationState extends State<CodeRestauration> {
  final _formKey = GlobalKey<FormState>();
  String? _code;
  final _codeController = TextEditingController();
  final _codeFocus = FocusNode();
  String codeRecuperation = "";
  String emailRecuperation = "";

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    load();
  }

  void load() async {
    var session = await SharedPreferences.getInstance();
    codeRecuperation = session.getString("codeRecuperation")!;
    emailRecuperation = session.getString("emailRecuperation")!;
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text(
            "Code de Récupération",
            style: TextStyle(
                color: Color(0xFF2F80F7),
                fontSize: 30,
                fontWeight: FontWeight.bold),
            textAlign: TextAlign.center,
          ),
          centerTitle: true,
          backgroundColor: const Color(0xFFE4E8E9),
          foregroundColor: Color(0xFF2F80F7),
          elevation: 0,
        ),
        body: Container(
          //padding: const EdgeInsets.symmetric(vertical: 100),
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          decoration: const BoxDecoration(color: Color(0xFFE4E8E9)),
          child: Form(
            key: _formKey,
            child: SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const SizedBox(height: 45),
                  Container(
                    margin: const EdgeInsets.symmetric(horizontal: 30),
                    child: const Text(
                      'Entrez le code de réinitialisation à cinq chiffres envoyé dans votre mail',
                      style: TextStyle(fontSize: 15),
                    ),
                  ),
                  const SizedBox(
                    height: 60,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      _buildCodeSquare(1),
                      _buildCodeSquare(2),
                      _buildCodeSquare(3),
                      _buildCodeSquare(4),
                      _buildCodeSquare(5),
                    ],
                  ),
                  const SizedBox(height: 20),
                  TextFormField(
                    maxLength: 5,
                    cursorColor: Colors.black,
                    cursorHeight: 25,
                    controller: _codeController,
                    focusNode: _codeFocus,
                    keyboardType: TextInputType.text,
                    textInputAction: TextInputAction.done,
                    validator: (value) {
                      if (value!.isEmpty) {
                        return 'Entrez un code';
                      }
                      if (value.length != 5) {
                        return 'Le code doit comporter 5 chiffres';
                      }
                      if (value != codeRecuperation) {
                        return 'Le code est incorrect';
                      }
                      return null;
                    },
                    onSaved: (value) => _code = value!,
                    onChanged: (value) {
                      setState(() {
                        _code = value;
                      });
                    },
                  ),
                  const SizedBox(
                    height: 60,
                  ),
                  Container(
                    width: 150,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10)),
                          primary: Colors.blue[900],
                          elevation: 5),
                      onPressed: () {
                        if (_formKey.currentState!.validate()) {
                          _formKey.currentState?.save();
                          print(codeRecuperation);
                          print(_codeController.text);
                          if (codeRecuperation == _codeController.text) {
                            Navigator.of(context)
                                .pushReplacement(MaterialPageRoute(
                              builder: (ctx) {
                                return const RestaurerPassword();
                              },
                            ));
                          }
                        }
                      },
                      child: const Text(
                        "Valider",
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 8,
                  ),
                  TextButton(
                    onPressed: () {
                      codeRecuperation = genererCodeRecuperation();
                      sendMailRecuperation(emailRecuperation, codeRecuperation);
                      print("Notifier email envoyer");
                      //Notifier email envoyer
                    },
                    child: Container(
                      margin: const EdgeInsets.symmetric(horizontal: 30),
                      width: MediaQuery.of(context).size.width,
                      alignment: Alignment.bottomLeft,
                      child: const Text(
                        'Code non reçu?',
                        style: TextStyle(
                          color: Color(0xFF2D48ED),
                          fontSize: 15,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ));
  }

  Widget _buildCodeSquare(int index) {
    return Container(
      width: 50,
      height: 50,
      decoration: BoxDecoration(
        border: Border.all(
          color: const Color(0xFF2F80F7),
        ),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Center(
        child: Text(
          _code != null && _code!.length >= index ? _code![index - 1] : '',
          style: const TextStyle(fontSize: 20, color: Colors.black),
        ),
      ),
    );
  }
}
