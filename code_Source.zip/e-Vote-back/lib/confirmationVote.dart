import 'package:e_vote/fileBack/api_DB.dart';
import 'package:e_vote/listCandidat.dart';
import 'package:e_vote/remerciement.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ConfirmationVote extends StatefulWidget {
  const ConfirmationVote({Key? key}) : super(key: key);

  @override
  State<ConfirmationVote> createState() => _ConfirmationVoteState();
}

class _ConfirmationVoteState extends State<ConfirmationVote> {
  var code;
  var email;
  var type;
  var id_C;
  var candidat;
  bool paus = true;
  bool isload = false;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    loading();
  }

  void loading() {
    SharedPreferences.getInstance().then((value) {
      code = value.getString('code');
      email = value.getString('email');
      type = value.getString('type');
      id_C = value.getInt('id_C');
      print(id_C);
      getCandidat(id_C.toString()).then((value) {
        if (value.runtimeType != bool) {
          setState(() {
            candidat = value;
            paus = false;
          });
        } else {
          print("Probleme de recuperation des candidat");
        }
      });
    });
  }

  Widget loadCard() {
    Widget select;
    paus
        ? select = const CircularProgressIndicator(
            color: Colors.red,
          )
        : select = Container(
            height: MediaQuery.of(context).size.height * 0.6,
            width: MediaQuery.of(context).size.width,
            margin: const EdgeInsets.symmetric(horizontal: 30),
            decoration: BoxDecoration(
                boxShadow: [
                  BoxShadow(
                    color: Colors.black12,
                    offset: Offset.fromDirection(10),
                    blurRadius: 3,
                  )
                ],
                gradient: const LinearGradient(
                  begin: Alignment.topRight,
                  end: Alignment.bottomLeft,
                  colors: [
                    Color.fromARGB(255, 131, 115, 115),
                    Color(0xFF2F80F7),
                  ],
                ),
                borderRadius: BorderRadius.circular(20)),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(90),
                  child: CircleAvatar(
                    radius: 65,
                    child: Center(
                      child: Image.asset(
                        "assets/profill.png",
                      ),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 20,
                ),
                Text(
                  "${candidat["nom"]} ${candidat["prenom"]}",
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                      color: Colors.black,
                      fontSize: 18,
                      fontWeight: FontWeight.bold),
                ),
                const SizedBox(
                  height: 60,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          elevation: 10,
                          shadowColor: Color.fromARGB(255, 73, 12, 12),
                          primary: const Color.fromARGB(255, 197, 61, 51),
                          padding: const EdgeInsets.symmetric(vertical: 15),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10)),
                        ),
                        onPressed: () {
                          Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (ctx) {
                                return const ListCandidat();
                              },
                            ),
                          );
                        },
                        child: Container(
                          // padding: EdgeInsets.symmetric(vertical: 5),
                          height: 20,
                          width: 100,
                          child: const Text(
                            'Non',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(
                      width: 50,
                    ),
                    Container(
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          elevation: 10,
                          shadowColor: Color.fromARGB(255, 73, 12, 12),
                          primary: const Color.fromARGB(255, 41, 167, 45),
                          padding: const EdgeInsets.symmetric(vertical: 15),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10)),
                        ),
                        onPressed: () {
                          isload = true;
                          setState(() {});
                          print("type: $type");
                          if (type == "Public") {
                            getElecteurPublic(email).then((electeur) {
                              //Verification si l'electeur a déjà voté
                              print(electeur);
                              if (electeur.runtimeType != bool) {
                                getElecteurPublicMarquer(
                                        code, electeur["id_epb"].toString())
                                    .then((marque) {
                                  print(marque);
                                  print(code);
                                  if (marque.runtimeType != bool) {
                                    SharedPreferences.getInstance()
                                        .then((value) {
                                      value.setString("msgFinVote",
                                          "Oups!!! vous avez déjà effectué votre vote");
                                      isload = false;
                                      setState(() {});
                                      Navigator.of(context).push(
                                        MaterialPageRoute(
                                          builder: (ctx) {
                                            return const remerciement();
                                          },
                                        ),
                                      );
                                    });
                                  }
                                });
                              } else {
                                //Inscription de l'electeur pour le vote
                                setElecteurPublic(email).then((eltPublic) {
                                  setMarqueElecteurPublic(
                                          code, eltPublic["id_epb"].toString())
                                      .then((inscrit) {
                                    //recuperation des voix du cadidat choisir
                                    getVoixCandidatToElection(
                                            code, id_C.toString())
                                        .then((valueVoix) {
                                      //Incrémentation du voix du candidat
                                      updateVoixCandidatToElection(
                                              code,
                                              id_C.toString(),
                                              (int.parse(valueVoix["voix"]) + 1)
                                                  .toString())
                                          .then((value) {
                                        SharedPreferences.getInstance()
                                            .then((value) {
                                          value.setString("msgFinVote",
                                              "Merci d'avoir effectué votre vote, celui-ci est pris en compte avec succès");
                                          isload = false;
                                          setState(() {});
                                          Navigator.of(context).push(
                                            MaterialPageRoute(
                                              builder: (ctx) {
                                                return const remerciement();
                                              },
                                            ),
                                          );
                                        });
                                      });
                                    });
                                  });
                                });
                              }
                            });
                          } else {
                            //Récuperation des infos sur l'electeur
                            getElecteurPriveById(email).then((electeur) {
                              //verification si il a déjà voté ou non
                              print(electeur["avoter"].runtimeType);
                              if (int.parse(electeur["avoter"]) == 0) {
                                //Marque l'electeur
                                setMarqueElecteurPrive(email).then((value) {
                                  //recuperation des voix du cadidat choisir
                                  getVoixCandidatToElection(
                                          code, id_C.toString())
                                      .then((valueVoix) {
                                    //Incrémentation du voix du candidat
                                    updateVoixCandidatToElection(
                                            code,
                                            id_C.toString(),
                                            (int.parse(valueVoix["voix"]) + 1)
                                                .toString())
                                        .then((value) {
                                      isload = false;
                                      setState(() {});
                                      SharedPreferences.getInstance()
                                          .then((value) {
                                        value.setString("msgFinVote",
                                            "Merci d'avoir effectué votre vote, celui-ci est pris en compte avec succès");
                                        Navigator.of(context).push(
                                          MaterialPageRoute(
                                            builder: (ctx) {
                                              return const remerciement();
                                            },
                                          ),
                                        );
                                      });
                                    });
                                  });
                                });
                              } else {
                                isload = false;
                                setState(() {});
                                SharedPreferences.getInstance().then((value) {
                                  value.setString("msgFinVote",
                                      "Oups!!! vous avez déjà effectué votre vote");
                                  print(value.getString("msgFinVote"));
                                  Navigator.of(context).push(
                                    MaterialPageRoute(
                                      builder: (ctx) {
                                        return const remerciement();
                                      },
                                    ),
                                  );
                                });
                              }
                            });
                          }
                        },
                        child: Container(
                          height: 20,
                          width: 100,
                          child: isload
                              ? const SizedBox(
                                  height: 5,
                                  width: 5,
                                  child: CircularProgressIndicator(
                                    color: Color.fromARGB(255, 255, 255, 255),
                                  ))
                              : const Text(
                                  'Confirmer',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold),
                                ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          );

    return select;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Container(
      //possss
      padding: EdgeInsets.symmetric(
          vertical: MediaQuery.of(context).size.height * 0.05),
      height: MediaQuery.of(context).size.height,
      width: MediaQuery.of(context).size.width,
      decoration: const BoxDecoration(
        color: Color(0xFFE4E8E9),
      ),

      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const SizedBox(height: 50),
          loadCard(),
        ],
      ),
    ));
  }
}
