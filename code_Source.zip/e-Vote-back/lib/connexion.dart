import 'package:e_vote/fileBack/api_DB.dart';
import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';
import 'package:e_vote/acceuil.dart';
import 'package:e_vote/dashbord.dart';
import 'package:e_vote/inscription.dart';
import 'package:e_vote/recuperation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Connexion extends StatefulWidget {
  const Connexion({Key? key}) : super(key: key);

  @override
  State<Connexion> createState() => _ConnexionState();
}

class _ConnexionState extends State<Connexion> {
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  final formKey = GlobalKey<FormState>();
  late bool isObscure = true;
  bool compteExist = false;
  bool passwordCorrect = false;
  bool isload = false;
  var tmp_password = "";
  var id_O;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "",
          style: TextStyle(
              color: Color(0xFF2F80F7),
              fontSize: 30,
              fontWeight: FontWeight.bold),
          textAlign: TextAlign.center,
        ),
        centerTitle: true,
        backgroundColor: const Color(0xFFE4E8E9),
        foregroundColor: Color(0xFF2F80F7),
        elevation: 0,
      ),
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        decoration: const BoxDecoration(
          color: Color(0xFFE4E8E9),
        ),
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(90),
                    child: CircleAvatar(
                      backgroundColor: const Color(0xFF2F80F7),
                      radius: 50,
                      child: Center(
                        child: Image.asset(
                          "assets/profill.png",
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 30,
                  ),
                  const Text(
                    "Connexion",
                    style: TextStyle(
                        fontSize: 40,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF2F80F7)),
                  ),
                  const SizedBox(height: 50),
                  Form(
                    key: formKey,
                    child: Column(
                      children: <Widget>[
                        Container(
                          margin: const EdgeInsets.symmetric(horizontal: 30),
                          child: TextFormField(
                              controller: emailController,
                              keyboardType: TextInputType.emailAddress,
                              textInputAction: TextInputAction.done,
                              textAlign: TextAlign.start,
                              decoration: const InputDecoration(
                                filled: true,
                                prefixIcon: Icon(
                                  Icons.mail_outline,
                                  size: 25,
                                  color: Colors.black,
                                ),
                                labelText: 'Email',
                                labelStyle: TextStyle(
                                  color: Colors.black,
                                ),
                                border: OutlineInputBorder(
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(8.0)),
                                  borderSide: BorderSide(color: Colors.black),
                                ),
                              ),
                              style: const TextStyle(color: Colors.black),
                              cursorColor: Colors.black,
                              showCursor: true,
                              validator: (value) {
                                if (value!.isEmpty) {
                                  return 'Ce champ est obligatoire';
                                }
                                if (!value.contains("@")) {
                                  return "L'email doit contenir @";
                                }
                                if (compteExist) {
                                  return "Ce adresse mail n'existe pas";
                                }
                                return null;
                              }),
                        ),
                        const SizedBox(height: 10),
                        Container(
                          margin: const EdgeInsets.symmetric(horizontal: 30),
                          child: TextFormField(
                              obscureText: isObscure,
                              controller: passwordController,
                              keyboardType: TextInputType.text,
                              textAlign: TextAlign.start,
                              decoration: InputDecoration(
                                filled: true,
                                suffixIcon: IconButton(
                                  hoverColor: Colors.transparent,
                                  splashColor: Colors.transparent,
                                  icon: Icon(isObscure
                                      ? Icons.visibility_off
                                      : Icons.visibility_sharp),
                                  onPressed: () {
                                    setState(() {
                                      isObscure = !isObscure;
                                    });
                                  },
                                ),
                                prefixIcon: const Icon(
                                  Icons.lock,
                                  size: 25,
                                  color: Colors.black,
                                ),
                                labelText: 'Mot de passe',
                                labelStyle: const TextStyle(
                                  color: Colors.black,
                                ),
                                border: const OutlineInputBorder(
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(8.0)),
                                  borderSide: BorderSide(color: Colors.black),
                                ),
                              ),
                              style: const TextStyle(
                                  //height: 1,
                                  color: Colors.black),
                              cursorColor: Colors.black,
                              validator: (value) {
                                if (tmp_password != passwordController.text) {
                                  return "Mot de passe incorrect";
                                }
                                return null;
                              }),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                ],
              ),
              TextButton(
                onPressed: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (ctx) {
                        return const Recuperation();
                      },
                    ),
                  );
                },
                child: Container(
                  margin: const EdgeInsets.symmetric(horizontal: 30),
                  width: MediaQuery.of(context).size.width,
                  alignment: Alignment.bottomLeft,
                  child: const Text(
                    'Mot de passe oublié ?',
                    style: TextStyle(
                      color: Color(0xFF2D48ED),
                      fontSize: 15,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10)),

                    //,
                    //ombreshadowColor: Colors.blue[900],
                    primary: Colors.blue[900],
                    elevation: 5),
                onPressed: () {
                  isload = true;
                  setState(() {});
                  getOrganisateurByEmail(emailController.text)
                      .then((compte) async {
                    if (compte.runtimeType != bool) {
                      compteExist = false;
                      id_O = compte["id_O"];
                      tmp_password = compte["password"];
                      print("ici ${compte["password"]}");
                    } else {
                      tmp_password = "";
                      compteExist = true;
                    }
                    if (formKey.currentState!.validate()) {
                      emailController.text = "";
                      passwordController.text = "";
                      tmp_password = "";
                      compteExist = false;
                      final session = await SharedPreferences.getInstance();
                      session.setInt("id_O", int.parse(id_O));
                      session.setString("nomOg", compte["nom"]);
                      session.setString("prenomOg", compte["prenom"]);
                      session.setString("emailOg", compte["email"]);
                      Navigator.of(context).pushReplacement(
                        MaterialPageRoute(
                          builder: (ctx) {
                            return const Dashbord();
                          },
                        ),
                      );
                    }
                    isload = false;
                    setState(() {});
                  });
                },
                child: isload
                    ? const SizedBox(
                        height: 20,
                        width: 20,
                        child: CircularProgressIndicator(
                          color: Color.fromARGB(255, 255, 255, 255),
                        ))
                    : const Text(
                        "Se connecter",
                        style: TextStyle(color: Colors.white),
                      ),
              ),
              const SizedBox(
                height: 40,
              ),
              const Text("Vous n'avez pas de compte?",
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
              const SizedBox(
                height: 15,
              ),
              TextButton(
                onPressed: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (ctx) {
                        return const Inscription();
                      },
                    ),
                  );
                },
                child: const Text(
                  'Inscrivez-vous ici',
                  style: TextStyle(
                    color: Color(0xFF2D48ED),
                    fontSize: 15,
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
