import 'dart:convert';
import 'dart:io';

import 'package:e_vote/acceuil.dart';
import 'package:e_vote/connexion.dart';
import 'package:e_vote/detail.dart';
import 'package:e_vote/detailOrganisation.dart';
import 'package:e_vote/fileBack/api_DB.dart';
import 'package:e_vote/fileBack/convertCSVtoList.dart';
import 'package:e_vote/fileBack/genererCode.dart';
import 'package:e_vote/fileBack/mailInvitation.dart';
import 'package:e_vote/fileBack/stringToDateTime.dart';
import 'package:e_vote/listCandidat.dart';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Dashbord extends StatefulWidget {
  const Dashbord({Key? key}) : super(key: key);

  @override
  State<Dashbord> createState() => _DashbordState();
}

class _DashbordState extends State<Dashbord> {
  String selectedchoice = "Public";
  int selectedIndex = 1;
  final nameController = TextEditingController();
  final descController = TextEditingController();
  final cand1Contoller = TextEditingController();
  final candController = TextEditingController();
  final elecController = TextEditingController();
  final dateDebutController = TextEditingController();
  final dateFinController = TextEditingController();
  final formKey = GlobalKey<FormState>();
  final formKey1 = GlobalKey<FormState>();
  final formKey2 = GlobalKey<FormState>();
  final formKeyCandidat = GlobalKey<FormState>();
  final formKeyElecteur = GlobalKey<FormState>();
  final formKeyDateDebut = GlobalKey<FormState>();
  final formKeyDateFin = GlobalKey<FormState>();
  var id_O;
  var elections;
  var codeVote;
  var nomOrganisateur;
  var prenomOrganisateur;
  var emailOrganisateur;
  bool isEnabled = true;
  bool term = false;
  bool creer = false;
  bool isload = false;
  List<List<dynamic>> listCandidat = [];
  List<List<dynamic>> listElecteur = [];
  String tmpMsg = "";
  String tmpMsg2 = "";

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    loadElections();
  }

  Future<String> getdate() async {
    DateTime? tmp1;
    var tmp2;
    tmp1 = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2023),
      lastDate: DateTime(2030),
    );
    tmp2 = tmp1 != null
        ? "${tmp1.year.toString()}-${tmp1.month.toString()}-${tmp1.day.toString()}"
        : "";
    return tmp2;
  }

  Future<String> getTime() async {
    TimeOfDay? tmp1;
    var tmp2;
    tmp1 = await showTimePicker(context: context, initialTime: TimeOfDay.now());
    tmp2 = tmp1 != null
        ? "${tmp1.hour.toString()}:${tmp1.minute.toString()}:00"
        : "";
    return tmp2;
  }

  //Récupere la liste des élections
  void loadElections() {
    SharedPreferences.getInstance().then((value) {
      id_O = value.getInt("id_O");
      nomOrganisateur = value.getString("nomOg");
      prenomOrganisateur = value.getString("prenomOg");
      emailOrganisateur = value.getString("emailOg");
      getAllElectionToOrganisateur(id_O.toString())
          .then((electionsToOrganisateur) {
        setState(() {
          elections = electionsToOrganisateur;
          id_O = value.getInt("id_O");
        });
      });
    });
  }

  Widget voteCreer() {
    var tmpCode = codeVote;
    //codeVote = "";
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Center(
            child: Padding(
          padding: const EdgeInsets.all(15.0),
          child: ClipOval(
            child: Image.asset(
              "assets/chek.png",
              width: 100,
              height: 100,
            ),
          ),
        )),
        Padding(
          padding: const EdgeInsets.all(20.0).copyWith(top: 20),
          child: Text(
            "Vote créé avec succes !!!",
            style: const TextStyle(
                color: Colors.black, fontWeight: FontWeight.bold),
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(20.0).copyWith(top: 20),
          child: Text(
            "Code de l'election est :  $tmpCode",
            style: const TextStyle(
                color: Colors.black, fontWeight: FontWeight.bold),
          ),
        ),
      ],
    );
  }

  Widget add() {
    setState(() {
      creer = false;
    });
    return Column(
      children: [
        const SizedBox(height: 5),
        const Text(
          "Créez une election",
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Colors.black,
          ),
        ),
        const SizedBox(
          height: 15,
        ),
        //champ du nom
        Form(
          key: formKey,
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.all(5),
                decoration: BoxDecoration(
                    color: Colors.white,
                    boxShadow: const [
                      BoxShadow(
                          color: Colors.black12,
                          offset: Offset(0, 5),
                          blurRadius: 10,
                          spreadRadius: 2)
                    ],
                    borderRadius: BorderRadius.circular(20)),
                child: TextFormField(
                    controller: nameController,
                    keyboardType: TextInputType.text,
                    // key: TextInputType.text,
                    decoration: const InputDecoration(
                        hintText: "Intitulé", border: InputBorder.none),
                    validator: (String? value) {
                      return (value == null || value == "")
                          ? "Ce champ est obligatoire"
                          : null;
                    }),
              ),
            ],
          ),
        ),
        const SizedBox(
          height: 15,
        ),
        //champ dde la description
        Form(
          key: formKey1,
          child: Container(
            padding: const EdgeInsets.all(5),
            decoration: BoxDecoration(
                color: Colors.white,
                boxShadow: const [
                  BoxShadow(
                      color: Colors.black12,
                      offset: Offset(0, 5),
                      blurRadius: 10,
                      spreadRadius: 2)
                ],
                borderRadius: BorderRadius.circular(20)),
            height: MediaQuery.of(context).size.height * 0.2,
            width: MediaQuery.of(context).size.width,
            child: TextFormField(
                controller: descController,
                keyboardType: TextInputType.multiline,
                maxLines: null, // key: TextInputType.text,
                decoration: const InputDecoration(
                    hintText: "Description du vote", border: InputBorder.none),
                validator: (String? value) {
                  return (value == null || value == "")
                      ? "Ce champ est obligatoire"
                      : null;
                }),
          ),
        ),
        const SizedBox(
          height: 20,
        ),
        const Text(
          "Type de vote",
          style: TextStyle(
              color: Colors.black, fontWeight: FontWeight.bold, fontSize: 18),
        ),
        //Champ de choix de type de vote
        Container(
          margin: const EdgeInsets.only(top: 10),
          decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: const [
                BoxShadow(
                    color: Colors.black12,
                    offset: Offset(0, 5),
                    blurRadius: 10,
                    spreadRadius: 2)
              ],
              borderRadius: BorderRadius.circular(10)),
          height: 50,
          width: MediaQuery.of(context).size.width,
          child: Row(
            children: [
              Flexible(
                flex: 5,
                child: RadioListTile(
                  value: "Public",
                  groupValue: selectedchoice,
                  onChanged: (value) {
                    setState(() {
                      selectedchoice = value.toString();
                    });
                  },
                  title: const Text("Public"),
                ),
              ),
              Flexible(
                flex: 5,
                child: RadioListTile(
                  value: "Privé",
                  groupValue: selectedchoice,
                  onChanged: (value) {
                    setState(() {
                      selectedchoice = value.toString();
                    });
                  },
                  title: const Text("Privé"),
                ),
              )
            ],
          ),
        ),
        const SizedBox(
          height: 15,
        ),
        //champ d'insertion de la liste des candidat via un fichier CSV
        Row(
          children: [
            Form(
              key: formKeyCandidat,
              child: Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                    color: Colors.white,
                    boxShadow: const [
                      BoxShadow(
                          color: Colors.black12,
                          offset: Offset(0, 5),
                          blurRadius: 5,
                          spreadRadius: 3)
                    ],
                    borderRadius: BorderRadius.circular(8)),
                height: MediaQuery.of(context).size.height * 0.06,
                width: MediaQuery.of(context).size.width * 0.6,
                child: TextFormField(
                    controller: candController,
                    enabled: false,
                    decoration: const InputDecoration(
                      hintText: "Ajouter une liste de candidats",
                      border: InputBorder.none,
                    ),
                    validator: (String? value) {
                      if (value == null || value == "") {
                        return "Ce champ est obligatoire";
                      }
                      /*if (listCandidat[0].length != 2) {
                                  return "Assurez vous que votre fichier CSV contient deux colonne";
                                }*/
                      return null;
                    }),
              ),
            ),
            Container(
              margin: const EdgeInsets.only(bottom: 20),
              child: IconButton(
                splashRadius: 1,
                onPressed: () async {
                  try {
                    final file = await FilePicker.platform.pickFiles(
                      type: FileType.custom,
                      allowedExtensions: ['csv'],
                    );
                    final input = file!.files.single.path;
                    listCandidat = await convertCSVtoList(File(input!));

                    setState(() {
                      candController.text = 'Candidats: ${file.names}';
                    });
                  } catch (e) {
                    print(e);
                  }
                },
                icon: const Icon(
                  Icons.add_circle_outlined,
                  color: Color(0xFF2D48ED),
                  size: 40,
                ),
              ),
            ),
          ],
        ),
        // champ optionnel qui apparait quand on choisir un vote privé afin d'insere la liste des électeurs
        Text(
          tmpMsg,
          style: const TextStyle(color: Colors.red, fontSize: 12),
          textAlign: TextAlign.start,
        ),
        Visibility(
            visible: selectedchoice == "Privé",
            child: Column(
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                          color: Colors.white,
                          boxShadow: const [
                            BoxShadow(
                                color: Colors.black12,
                                offset: Offset(0, 5),
                                blurRadius: 5,
                                spreadRadius: 3)
                          ],
                          borderRadius: BorderRadius.circular(8)),
                      height: MediaQuery.of(context).size.height * 0.06,
                      width: MediaQuery.of(context).size.width * 0.6,
                      child: TextFormField(
                        key: formKeyElecteur,
                        controller: elecController,
                        enabled: false,
                        decoration: InputDecoration(
                          hintText: "Ajouter une liste d'électeurs",
                          border: InputBorder.none,
                        ),
                        validator: (String? value) {
                          if (value == null || value == "") {
                            return "Ce champ est obligatoire";
                          }
                          if (listElecteur[0].length != 1) {
                            return "Assurez vous que votre fichier CSV contient une seule colonne";
                          }
                          return null;
                        },
                      ),
                    ),
                    Container(
                      margin: const EdgeInsets.only(bottom: 20),
                      child: IconButton(
                        splashRadius: 1,
                        onPressed: () async {
                          try {
                            final file = await FilePicker.platform.pickFiles(
                              type: FileType.custom,
                              allowedExtensions: ['csv'],
                            );
                            final input = file!.files.single.path;
                            listElecteur = await convertCSVtoList(File(input!));
                            setState(() {
                              elecController.text = 'Electeurs: ${file.names}';
                            });
                          } catch (e) {
                            print(e);
                          }
                        },
                        icon: const Icon(
                          Icons.add_circle_outlined,
                          color: Color(0xFF2D48ED),
                          size: 40,
                        ),
                      ),
                    ),
                  ],
                ),
                Text(
                  tmpMsg2,
                  style: const TextStyle(color: Colors.red, fontSize: 12),
                  textAlign: TextAlign.start,
                ),
              ],
            )),
        const SizedBox(height: 30),
        const Text(
          "Gestion de Date",
          style: TextStyle(
              color: Colors.black, fontWeight: FontWeight.bold, fontSize: 18),
        ),
        const SizedBox(height: 30),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                  color: Colors.white,
                  boxShadow: const [
                    BoxShadow(
                        color: Colors.black12,
                        offset: Offset(0, 5),
                        blurRadius: 5,
                        spreadRadius: 3)
                  ],
                  borderRadius: BorderRadius.circular(8)),
              //height: MediaQuery.of(context).size.height * 0.06,
              width: 150,
              child: Form(
                key: formKeyDateDebut,
                child: TextFormField(
                    controller: dateDebutController,
                    decoration: const InputDecoration(
                      hintText: "Début",
                      border: InputBorder.none,
                    ),
                    onTap: () async {
                      var tmp1 = await getdate();
                      var tmp2 = await getTime();
                      dateDebutController.text = "$tmp1 $tmp2";
                    },
                    validator: (String? value) {
                      if (value == null || value == "") {
                        return "Obligatoire";
                      }
                      //Regex pour verifier le contenu est aaaa-mm-dd
                      return null;
                    }),
              ),
            ),
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                  color: Colors.white,
                  boxShadow: const [
                    BoxShadow(
                        color: Colors.black12,
                        offset: Offset(0, 5),
                        blurRadius: 5,
                        spreadRadius: 3)
                  ],
                  borderRadius: BorderRadius.circular(8)),
              //height: MediaQuery.of(context).size.height * 0.06,
              width: 150,
              child: Form(
                  key: formKeyDateFin,
                  child: TextFormField(
                      controller: dateFinController,
                      decoration: const InputDecoration(
                        hintText: "Fin",
                        border: InputBorder.none,
                      ),
                      onTap: () async {
                        var tmp1 = await getdate();
                        var tmp2 = await getTime();
                        dateFinController.text = "$tmp1 $tmp2";
                      },
                      validator: (String? value) {
                        if (value == null || value == "") {
                          return "Obligatoire";
                        }

                        return null;
                      })),
            ),
          ],
        ),
        /*ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        backgroundColor: Color.fromARGB(255, 255, 255, 255),
                        padding: const EdgeInsets.all(0)),
                    onPressed: () {
                      var date;
                      var time;                
                      showDatePicker(
                        context: context,
                        initialDate: DateTime.now(),
                        firstDate: DateTime.now(),
                        lastDate: DateTime(2030),
                      ).then((value) {
                        date = value.toString();
                        
                        // do something with the date selected
                      });
                    },
                    child: Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                          color: Colors.white,
                          boxShadow: const [
                            BoxShadow(
                                color: Colors.black12,
                                offset: Offset(0, 5),
                                blurRadius: 5,
                                spreadRadius: 3)
                          ],
                          borderRadius: BorderRadius.circular(8)),
                      height: MediaQuery.of(context).size.height * 0.06,
                      width: 150,
                      child: TextFormField(
                          enabled: false,
                          controller: dateDebutController,
                          decoration: const InputDecoration(
                            hintText: "Début",
                            border: InputBorder.none,
                          ),
                          validator: (String? value) {
                            if (value == null || value == "") {
                              return "Ce champ est obligatoire";
                            }
                            return null;
                          }),
                    ),
                  ),*/
        const SizedBox(height: 30),
        Container(
          width: 150,
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(
                shadowColor: const Color.fromARGB(255, 73, 12, 12),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10)),
                primary: Colors.blue[900],
                elevation: 10),
            onPressed: () {
              // isload = true;
              // setState(() {});
              var nom = nameController.text;
              var description = descController.text;
              var begin = dateDebutController.text;
              var end = dateFinController.text;
              var type = selectedchoice;
              bool chkNom = false;
              bool chkdescrip = false;
              bool chkListCandidat = false;
              bool chkListElecteur = false;
              bool chkDateDebut = false;
              bool chkDateFin = false;
              bool chkFirst = false;
              codeVote = genererCode();
              try {
                //Verification des champs
                (formKey.currentState!.validate())
                    ? chkNom = true
                    : chkNom = false;
                (formKey1.currentState!.validate())
                    ? chkdescrip = true
                    : chkdescrip = false;
                if (candController.text != "") {
                  if (listCandidat[0].length == 2) {
                    chkListCandidat = true;
                    setState(() {
                      tmpMsg = "";
                    });
                  } else {
                    chkListCandidat = false;
                    setState(() {
                      tmpMsg = "Syntaxe incorrete, Consultez le guide";
                    });
                  }
                } else {
                  chkListCandidat = false;
                  setState(() {
                    tmpMsg = "Ce champ est obligatoire";
                  });
                }
                if (selectedchoice == "Privé" && elecController.text != "") {
                  if (listElecteur[0].length == 1) {
                    chkListElecteur = true;
                    setState(() {
                      tmpMsg2 = "";
                    });
                  } else {
                    chkListElecteur = false;
                    setState(() {
                      tmpMsg2 = "Syntaxe incorrete, Consultez le guide";
                    });
                  }
                } else {
                  chkListElecteur = false;
                  setState(() {
                    tmpMsg2 = "Ce champ est obligatoire";
                  });
                }
                (formKeyDateDebut.currentState!.validate())
                    ? chkDateDebut = true
                    : chkDateDebut = false;
                (formKeyDateFin.currentState!.validate())
                    ? chkDateFin = true
                    : chkDateFin = false;
                /* (selectedchoice == "Privé" &&
                        formKeyCandidat.currentState!.validate())
                    ? chkListElecteur = true
                    : chkListElecteur = false;*/
                if (chkNom &&
                    chkdescrip &&
                    chkListCandidat &&
                    chkDateDebut &&
                    chkDateFin) {
                  chkFirst = true;
                  //insertion de l'election dans la DB
                  inscritElection(codeVote, nom, description, begin, end, type,
                      id_O.toString());
                  print(codeVote);

                  for (var candidat in listCandidat) {
                    print(codeVote);
                    SharedPreferences.getInstance().then((value) {
                      value.setString("codeVote", codeVote);
                    });
                    var nom = candidat[0];
                    var prenom = candidat[1];
                    var id_C;
                    //insertion des candidat dans la DB
                    getCandidatByName(nom, prenom).then((value) {
                      if (value.runtimeType != bool) {
                        id_C = value["id_C"];
                        SharedPreferences.getInstance().then((value) {
                          inscritCandidatToElection(
                                  value.getString("codeVote")!, id_C.toString())
                              .then((value) {
                            print("$id_C => $value");
                          });
                        });
                      } else {
                        inscritCandidat(nom, prenom).then((value) {
                          id_C = value["id_C"];
                          SharedPreferences.getInstance().then((value) {
                            inscritCandidatToElection(
                                    value.getString("codeVote")!,
                                    id_C.toString())
                                .then((value) {
                              print("$id_C => $value");
                              isload = false;
                              setState(() {});
                              //Election public crée
                            });
                          });
                        });
                      }
                    });
                  }
                  if (selectedchoice == "Public") {
                    setState(() {
                      nameController.text = "";
                      descController.text = "";
                      candController.text = "";
                      elecController.text = "";
                      dateDebutController.text = "";
                      dateFinController.text = "";
                      //Faire appel a une page de fin de création
                      creer = true;
                    });
                  }

                  print("Vote Public");
                } else {
                  //isload = false;
                  //setState(() {});
                }
                //Inserer les electeurs prive
                if (selectedchoice == "Privé" && chkListElecteur && chkFirst) {
                  isload = true;
                  setState(() {});
                  for (var email in listElecteur) {
                    var id_epv = genererCode();
                    inscritElecteurToElectionPrive(id_epv, codeVote, email[0]);
                    try {
                      sendMailInvitation(
                          email[0], codeVote, id_epv, dateFinController.text);
                    } catch (e) {
                      print("Echec d'envoie des invitations: $e");
                      break;
                    }
                  }
                  // isload = false;
                  // setState(() {});

                  setState(() {
                    nameController.text = "";
                    descController.text = "";
                    candController.text = "";
                    elecController.text = "";
                    dateDebutController.text = "";
                    dateFinController.text = "";
                    //Faire appel a une page de fin de création
                    creer = true;
                  });
                  print("Vote Privé");
                } else {
                  //isload = false;
                  //setState(() {});
                }
              } catch (e) {
                print('ici: te$e');
              }
            },
            child: isload
                ? const SizedBox(
                    height: 20,
                    width: 20,
                    child: CircularProgressIndicator(
                      color: Color.fromARGB(255, 255, 255, 255),
                    ))
                : const Text(
                    "Enregistrer",
                    style: TextStyle(color: Colors.white),
                  ),
          ),
        ),
        const SizedBox(height: 30),
      ],
    );
  }

  List<Widget> loadList() {
    setState(() {
      creer = false;
    });
    List<Widget> lists = [];
    if (elections.runtimeType != bool) {
      for (var elec in elections) {
        var statut;
        Color colorState;
        if (DateTime.now().isBefore(stringToDateTime(elec["begin"]))) {
          statut = "En attente";
          colorState = const Color(0xFFFFD000);
        } else {
          if (DateTime.now().isBefore(stringToDateTime(elec["end"]))) {
            statut = "En cours";
            colorState = const Color(0xFF4CAF50);
          } else {
            statut = "Terminé";
            colorState = Color(0xFFFF0000);
          }
        }
        lists.add(
          Container(
            padding: const EdgeInsets.all(10),
            margin: const EdgeInsets.symmetric(horizontal: 25),
            height: MediaQuery.of(context).size.height * 0.2,
            width: MediaQuery.of(context).size.width * 0.8,
            decoration: BoxDecoration(
              color: Colors.white30,
              boxShadow: const [
                BoxShadow(
                    color: Colors.black12,
                    offset: Offset(0, 5),
                    blurRadius: 5,
                    spreadRadius: 3)
              ],
              borderRadius: BorderRadius.circular(10),
            ),
            child: Center(
                child: Column(
              children: [
                Text(
                  elec["nom"],
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(
                  height: 5,
                ),
                Text(
                  '(${elec["code"]})',
                  style: const TextStyle(
                    fontSize: 15,
                  ),
                ),
                const SizedBox(
                  height: 5,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Column(
                      children: [
                        Icon(
                          Icons.dock,
                          color: colorState,
                        ),
                        const SizedBox(
                          height: 1,
                        ),
                        Text(
                          statut,
                          style: const TextStyle(fontSize: 15),
                        )
                      ],
                    ),
                    const SizedBox(
                      width: 30,
                    ),
                    Container(
                      width: 150,
                      height: 40,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          shadowColor: Color.fromARGB(255, 73, 12, 12),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10)),
                          //ombreshadowColor: Colors.blue[900],
                          primary: Colors.blue[900],
                          elevation: 10,
                        ),
                        onPressed: () {
                          SharedPreferences.getInstance().then((value) {
                            value.setString('code', elec["code"]);
                            value.setString('type', elec["type"]);
                            value.setString("desc", elec["description"]);
                            value.setString("nom", elec["nom"]);
                            value.setString("end", elec["end"]);
                            value.setString("create_at", elec["create_at"]);
                            value.setString("begin", elec["begin"]);
                          });
                          Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (ctx) {
                                return const DetailOrganisation();
                              },
                            ),
                          );
                        },
                        child: const Text(
                          "Détails",
                          style: TextStyle(color: Colors.white),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            )),
          ),
        );
        lists.add(
          const SizedBox(height: 20),
        );
      }
    } else {
      Fluttertoast.showToast(
          msg: "Échec de chargement de la liste des élections");
    }
    return lists;
  }

  Widget profil() {
    return Container(
        child: Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(90),
            child: CircleAvatar(
              backgroundColor: const Color(0xFF2F80F7),
              radius: 50,
              child: Center(
                child: Image.asset(
                  "assets/profill.png",
                ),
              ),
            ),
          ),
          const SizedBox(
            height: 15,
          ),
          Container(
              padding: EdgeInsets.fromLTRB(60, 0, 0, 0),
              //decoration: BoxDecoration(border: Border.all()),
              margin: const EdgeInsets.all(10),
              width: MediaQuery.of(context).size.width / 0.8,
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Text(
                        "Nom: ",
                        style: TextStyle(
                            fontSize: 15, fontWeight: FontWeight.bold),
                      ),
                      Text(
                        nomOrganisateur,
                        style: TextStyle(
                            fontSize: 15, fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 5,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Text(
                        "Prénom: ",
                        style: TextStyle(
                            fontSize: 15, fontWeight: FontWeight.bold),
                      ),
                      Text(
                        prenomOrganisateur,
                        style: TextStyle(
                            fontSize: 15, fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 5,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Text(
                        "Email: ",
                        style: TextStyle(
                            fontSize: 15, fontWeight: FontWeight.bold),
                      ),
                      Text(
                        emailOrganisateur,
                        style: TextStyle(
                            fontSize: 15, fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                ],
              )),
          const SizedBox(
            height: 15,
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (ctx) {
                    return const Acceuil();
                  },
                ),
              );
            },
            child: const Text("Deconnexion"),
            style: ElevatedButton.styleFrom(primary: Colors.red),
          )
        ],
      ),
    ));
  }

  Widget listElection() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      children: loadList(),
    );
  }

  Widget? stateCurrent() {
    if (creer) {
      return voteCreer();
    } else {
      switch (selectedIndex) {
        case 0:
          return listElection();
        case 1:
          return add();
        case 2:
          return profil();
        default:
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text(
            "Dashboard",
            style: TextStyle(
                color: Color(0xFF2F80F7),
                fontSize: 30,
                fontWeight: FontWeight.bold),
            textAlign: TextAlign.center,
          ),
          actions: [
            IconButton(
                onPressed: () async {
                  final prefs = await SharedPreferences.getInstance();
                  await prefs.clear();

                  Navigator.pushReplacement(context,
                      MaterialPageRoute(builder: (context) => Acceuil()));
                },
                icon: Icon(Icons.logout))
          ],
          centerTitle: true,
          backgroundColor: const Color(0xFFE4E8E9),
          foregroundColor: Color(0xFF2F80F7),
          elevation: 0,
        ),
        body: Container(
          color: Colors.white38,
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          child: Container(
            decoration: const BoxDecoration(color: Color(0xFFE4E8E9)),
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
            child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(vertical: 20),
                scrollDirection: Axis.vertical,
                child: stateCurrent()),
          ),
        ),
        bottomNavigationBar: Container(
          //margin: EdgeInsets.all(10),
          decoration: const BoxDecoration(
              gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              //Color.fromARGB(255, 0, 0, 0),
              //Color(0xFF2DEDC5),
              Color(0xFFE4E8E9),
              //Color(0xFF2DEDC5),
              // Color.fromARGB(255, 0, 0, 0),
              Color.fromARGB(255, 39, 146, 247),
              //Color(0xFF36A9E1),
              //Color(0xFF2FE9F7),
            ],
          )),
          child: ClipRRect(
            //margin: EdgeInsets.all(10),

            borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
            //),
            child: BottomNavigationBar(
              // enableFeedback: true,
              elevation: 30,
              backgroundColor: Color.fromARGB(0, 54, 168, 225),

              items: const <BottomNavigationBarItem>[
                BottomNavigationBarItem(
                  icon: Icon(
                    Icons.copy_all_outlined,
                    //color: Colors.black,
                  ),
                  label: "Dossiers",
                ),
                BottomNavigationBarItem(
                  icon: Icon(
                    Icons.add_circle_outlined,
                    size: 50,
                    //color: Colors.black,
                  ),
                  label: "Ajouter",
                ),
                BottomNavigationBarItem(
                  icon: Icon(
                    Icons.person,
                    //color: Colors.black,
                  ),
                  label: "Profil",
                )
              ],
              currentIndex: selectedIndex,
              selectedItemColor: const Color(0xFF2D48ED),
              onTap: (int index) {
                setState(() {
                  loadElections();
                  creer = false;
                  selectedIndex = index;
                  print(index);
                });
              },
            ),
          ),
        ));
  }
}
