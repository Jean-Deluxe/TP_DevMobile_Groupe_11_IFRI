import 'dart:ui';

import 'package:e_vote/cloturer.dart';
import 'package:e_vote/fileBack/stringToDateTime.dart';
import 'package:e_vote/listCandidat.dart';
import 'package:e_vote/resultat.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:e_vote/partclass/cand.dart';
import 'package:e_vote/partclass/pourc.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Detail extends StatefulWidget {
  const Detail({Key? key}) : super(key: key);

  @override
  State<Detail> createState() => _DetailState();
}

class _DetailState extends State<Detail> {
  var nom = "";
  var description = "";
  var end = "";
  bool isload = false;
  bool isloadResultat = false;
  void initState() {
    // TODO: implement initState
    super.initState();
    load();
  }

  void load() {
    SharedPreferences.getInstance().then((value) {
      print(value);
      setState(() {
        nom = value.getString("nom")!;
        description = value.getString("desc")!;
        end = value.getString("end")!;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          nom,
          style: const TextStyle(
              color: Color(0xFF2F80F7),
              fontSize: 30,
              fontWeight: FontWeight.bold),
          textAlign: TextAlign.center,
        ),
        centerTitle: true,
        backgroundColor: const Color(0xFFE4E8E9),
        foregroundColor: Color(0xFF2F80F7),
        elevation: 0,
      ),
      body: Container(
        color: Color(0xFFE4E8E9),
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Padding(
                padding: EdgeInsets.only(top: 25),
                child: Text("Description du vote",
                    style:
                        TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
              ),
              Container(
                padding:
                    const EdgeInsets.symmetric(vertical: 20, horizontal: 10),
                margin: const EdgeInsets.symmetric(vertical: 15),
                width: MediaQuery.of(context).size.width,
                decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.all(const Radius.circular(10))),
                child: Text(
                  description,
                  style: const TextStyle(fontWeight: FontWeight.w500),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 15),
                child: ElevatedButton(
                  onPressed: () {
                    isload = true;
                    setState(() {});
                    if (DateTime.now().isBefore(stringToDateTime(end))) {
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (ctx) {
                            return const ListCandidat();
                          },
                        ),
                      );
                    } else {
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (ctx) {
                            return const Cloturer();
                          },
                        ),
                      );
                    }
                    isload = false;
                    setState(() {});
                  },
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(horizontal: 35),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30.0),
                    ),
                    primary: const Color(0xFF2F80F7),
                  ),
                  child: isload
                      ? const SizedBox(
                          height: 20,
                          width: 20,
                          child: CircularProgressIndicator(
                            color: Color.fromARGB(255, 255, 255, 255),
                          ))
                      : const Text(
                          "Passez au vote",
                          style: TextStyle(fontSize: 16),
                        ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 10),
                child: ElevatedButton(
                  onPressed: () {
                    isloadResultat = true;
                    setState(() {});
                    SharedPreferences.getInstance().then((value) {
                      if (DateTime.now().isBefore(
                              stringToDateTime(value.getString("end")!)) ||
                          DateTime.now().isAtSameMomentAs(
                              stringToDateTime(value.getString("end")!))) {
                        Fluttertoast.showToast(
                            msg:
                                "Merci de patienter l'election est toujours en cours");
                        print(
                            "Merci de patienter l'election est toujours en cours");
                      } else {
                        Navigator.of(context).push(
                          MaterialPageRoute(
                            builder: (ctx) {
                              return const Resultat();
                            },
                          ),
                        );
                      }
                      isloadResultat = true;
                      setState(() {});
                    });
                  },
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(horizontal: 35),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30.0),
                    ),
                    primary: const Color(0xFF2F80F7),
                  ),
                  child: const Text(
                    "Résultat du vote",
                    style: TextStyle(fontSize: 16),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
