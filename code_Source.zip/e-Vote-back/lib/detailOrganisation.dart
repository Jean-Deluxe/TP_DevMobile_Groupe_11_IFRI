import 'dart:ui';

import 'package:e_vote/cloturer.dart';
import 'package:e_vote/dashbord.dart';
import 'package:e_vote/fileBack/api_DB.dart';
import 'package:e_vote/fileBack/stringToDateTime.dart';
import 'package:e_vote/listCandidat.dart';
import 'package:e_vote/resultat.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:e_vote/partclass/cand.dart';
import 'package:e_vote/partclass/pourc.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:shared_preferences/shared_preferences.dart';

class DetailOrganisation extends StatefulWidget {
  const DetailOrganisation({Key? key}) : super(key: key);

  @override
  State<DetailOrganisation> createState() => _DetailOrganisationState();
}

class _DetailOrganisationState extends State<DetailOrganisation> {
  var nom = "";
  var description = "";
  var end = "";
  var create_at = "";
  var statut = "";
  var code = "";
  var begin = "";
  var colorState;
  void initState() {
    // TODO: implement initState
    super.initState();
    load();
  }

  void load() {
    SharedPreferences.getInstance().then((value) {
      print(value);
      setState(() {
        if (DateTime.now()
            .isBefore(stringToDateTime(value.getString("begin")!))) {
          statut = "En attente";
          colorState = const Color(0xFFFFD000);
        } else {
          if (DateTime.now()
              .isBefore(stringToDateTime(value.getString("end")!))) {
            statut = "En cours";
            colorState = const Color(0xFF4CAF50);
          } else {
            statut = "Terminé";
            colorState = Color(0xFFFF0000);
          }
        }
        nom = value.getString("nom")!;
        description = value.getString("desc")!;
        end = value.getString("end")!;
        begin = value.getString("begin")!;
        code = value.getString("code")!;
        create_at = value.getString("create_at")!;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          nom,
          style: const TextStyle(
              color: Color(0xFF2F80F7),
              fontSize: 30,
              fontWeight: FontWeight.bold),
          textAlign: TextAlign.center,
        ),
        centerTitle: true,
        backgroundColor: const Color(0xFFE4E8E9),
        foregroundColor: Color(0xFF2F80F7),
        elevation: 0,
      ),
      body: Container(
        color: Color(0xFFE4E8E9),
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Padding(
                padding: EdgeInsets.only(top: 25),
                child: Text("Description du vote",
                    style:
                        TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
              ),
              Container(
                padding:
                    const EdgeInsets.symmetric(vertical: 20, horizontal: 10),
                margin: const EdgeInsets.symmetric(vertical: 15),
                width: MediaQuery.of(context).size.width,
                decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.all(const Radius.circular(10))),
                child: Text(
                  description,
                  style: const TextStyle(fontWeight: FontWeight.w500),
                ),
              ),
              Row(
                children: [
                  Icon(
                    Icons.dock,
                    color: colorState,
                  ),
                  const SizedBox(
                    height: 1,
                  ),
                  Text(
                    statut,
                    style: const TextStyle(fontSize: 15),
                  )
                ],
              ),
              Text("Election débute le $begin"),
              Text("Election termine le $begin"),
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 10),
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (ctx) {
                          return const Resultat();
                        },
                      ),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(horizontal: 35),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30.0),
                    ),
                    primary: const Color(0xFF2F80F7),
                  ),
                  child: const Text(
                    "Resultat du vote",
                    style: TextStyle(fontSize: 16),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 10),
                child: ElevatedButton(
                  onPressed: () {
                    deleteElection(code).then((val) {
                      Fluttertoast.showToast(msg: "Vote supprimé");

                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (ctx) {
                            return const Dashbord();
                          },
                        ),
                      );
                    });
                  },
                  style: ElevatedButton.styleFrom(
                    onPrimary: Colors.red,
                    padding: const EdgeInsets.symmetric(horizontal: 35),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30.0),
                    ),
                    primary: const Color(0xFF2F80F7),
                  ),
                  child: const Text(
                    "Supprimer",
                    style: TextStyle(fontSize: 16),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
