import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:pie_chart/pie_chart.dart';
import 'package:e_vote/partclass/cand.dart';

class Draw extends StatefulWidget {
  const Draw({Key? key}) : super(key: key);

  @override
  State<Draw> createState() => _DrawState();
}

class _DrawState extends State<Draw> {
  int selectedIndex = 0;
  final dataMap = <String, double>{
    "Flutter": 5,
    "React": 3,
    "Xamarin": 2,
    "Ionic": 2,
    "Xama": 1,
    "Ion": 4,
  };

  final colorList = <Color>[
    const Color(0xfffdcb6e),
    const Color(0xff0984e3),
    const Color(0xfffd79a8),
    const Color(0xffe17055),
    const Color(0xff6c5ce7),
    const Color.fromARGB(255, 40, 105, 13),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blueAccent,
        title: const Text("Statistiques"),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 100),
          child: Column(
            children: [
              PieChart(
                dataMap: dataMap,
                animationDuration: const Duration(milliseconds: 800),
                chartLegendSpacing: 100,
                chartRadius: MediaQuery.of(context).size.width / 3,
                colorList: colorList,
                initialAngleInDegree: 0,
                chartType: ChartType.ring,
                ringStrokeWidth: 80,
                centerText: "Stats",
                centerTextStyle: TextStyle(
                    color: Colors.blue[900],
                    fontWeight:
                        FontWeight.bold /*,backgroundColor: Colors.grey*/),
                legendOptions: const LegendOptions(
                  showLegendsInRow: false,
                  legendPosition: LegendPosition.bottom,
                  showLegends: true,
                  legendShape: BoxShape.rectangle,
                  legendTextStyle: TextStyle(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                chartValuesOptions: const ChartValuesOptions(
                  showChartValueBackground: true,
                  showChartValues: true,
                  showChartValuesInPercentage: true,
                  showChartValuesOutside: true,
                  decimalPlaces: 2,
                ),
              ),
            ],
          ),
        ),
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            Container(
              height: MediaQuery.of(context).size.height * 0.3,
              width: MediaQuery.of(context).size.width,
              child: DrawerHeader(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topRight,
                    end: Alignment.bottomLeft,
                    colors: [
                      Colors.white,
                      Color(0xFF2D48ED),
                    ],
                  ),
                ),
                child: Center(
                    child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(90),
                      child: CircleAvatar(
                        radius: 50,
                        child: Center(
                          child: Image.asset(
                            "assets/profill.png",
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 3,
                    ),
                    const Text('Mimi la star',
                        style: TextStyle(color: Colors.white, fontSize: 20)),
                    const SizedBox(
                      height: 3,
                    ),
                    const Text('Mimi la star',
                        style: TextStyle(color: Colors.black, fontSize: 16)),
                  ],
                )),
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(vertical: 100),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ElevatedButton(
                      onPressed: () {},
                      child: Row(
                        children: const [
                          CircleAvatar(
                            backgroundColor: Colors.grey,
                            radius: 15,
                            child: Icon(
                              Icons.question_mark_sharp,
                              size: 25,
                              color: Colors.black,
                            ),
                          ),
                          SizedBox(
                            width: 25,
                          ),
                          Text('Guide',
                              style: TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 18)),
                        ],
                      )),
                  const SizedBox(
                    height: 30,
                  ),
                  ElevatedButton(
                      onPressed: () {},
                      child: Row(
                        children: const [
                          Icon(
                            Icons.app_settings_alt,
                            size: 25,
                            color: Colors.black,
                          ),
                          SizedBox(
                            width: 5,
                          ),
                          Text('Parametres',
                              style: TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 18)),
                        ],
                      )),
                  const SizedBox(
                    height: 100,
                  ),
                  Container(
                    margin: EdgeInsets.symmetric(
                        horizontal: MediaQuery.of(context).size.width * 0.15),
                    height: 30,
                    width: MediaQuery.of(context).size.width * 0.5,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        shadowColor: Color.fromARGB(255, 73, 12, 12),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10)),
                        primary: Colors.blue[900],
                        elevation: 10,
                      ),
                      onPressed: () {},
                      child: Row(
                        children: const [
                          Icon(
                            Icons.power_settings_new_rounded,
                          ),
                          SizedBox(
                            width: 10,
                          ),
                          Text(
                            "Déconnexion",
                            style: TextStyle(color: Colors.white),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        elevation: 20,
        backgroundColor: const Color.fromARGB(255, 189, 197, 202),
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(
              Icons.copy_all_outlined,
              //color: Colors.black,
              size: 40,
            ),
            label: "Dossiers",
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.add_circle_outlined,
              //color: Colors.black,
              size: 40,
            ),
            label: "Ajouter",
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.person,
              //color: Colors.black,
              size: 40,
            ),
            label: "Profil",
          )
        ],
        currentIndex: selectedIndex,
        selectedItemColor: const Color(0xFF2D48ED),
        onTap: (int index) {
          setState(() {
            selectedIndex = index;
          });
        },
      ),
    );
  }
}
