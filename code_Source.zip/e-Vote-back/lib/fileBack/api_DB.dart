import 'dart:convert';

import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:path/path.dart';

Future<bool> inscritOrganisateur(
    String nom, String prenom, String email, String password) async {
  try {
    var url = Uri.http('e-vote.x10.mx', '/setOrganisateur.php');
    url.toString();
    var response = await http.post(url, body: {
      'nom': nom,
      'prenom': prenom,
      'email': email,
      'password': password
    });

    if (response.statusCode == 200) {
      // Si la réponse est correcte, parsez le contenu de la réponse en JSON
      final data = json.decode(response.body);
      return true;
    } else {
      // Si la réponse est incorrecte, affichez l'erreur
      print(response.statusCode);
      Fluttertoast.showToast(msg: "Un problème s'est posé, merci de réessayer");
      return false;
    }
    //print('Response status: ${response.statusCode}');
    //print('Response body: ${response.body}');
  } catch (e) {
    Fluttertoast.showToast(msg: "Échec de connexion vers le serveur de DB");
    Fluttertoast.showToast(msg: "Vérifiez votre connexion");
    print("a exception :" + e.toString());
    return false;
  }
}

Future<bool> checkMail(String email) async {
  var url = Uri.http('e-vote.x10.mx', '/checkMail.php');
  url.toString();
  try {
    var response = await http.post(url, body: {'email': email});
    if (response.statusCode == 200) {
      // Si la réponse est correcte, parsez le contenu de la réponse en JSON
      try {
        final data = json.decode(response.body);
        var val = data[0];
        //int val1 = int.parse(val);
        return (val['nbr'] > 0) ? false : true;
      } catch (e) {
        print(e);
      }
      return true;
    } else {
      // Si la réponse est incorrecte, affichez l'erreur
      Fluttertoast.showToast(msg: "Un problème s'est posé, merci de réessayer");
      print(response.statusCode);
      return false;
    }
  } catch (e) {
    Fluttertoast.showToast(msg: "Un problème s'est posé, $e");
    print(e);
    return false;
  }
}

Future<dynamic> getOrganisateurByEmail(String email) async {
  var url = Uri.http('e-vote.x10.mx', '/getOrganisateurByEmail.php');
  url.toString();
  try {
    var response = await http.post(url, body: {'email': email});
    print('msg: ${response.statusCode}');
    if (response.statusCode == 200) {
      // Si la réponse est correcte, parsez le contenu de la réponse en JSON
      final data = json.decode(response.body);
      return data;
    } else {
      // Si la réponse est incorrecte, affichez l'erreur
      print(response.statusCode);
      Fluttertoast.showToast(msg: "Un problème s'est posé, merci de réessayer");
      return null;
    }
  } catch (e) {
    Fluttertoast.showToast(msg: "Échec de connexion vers le serveur de DB");
    Fluttertoast.showToast(msg: "Vérifiez votre connexion");
    print(e);
    return null;
  }
}

Future<bool> inscritElection(String code, String nom, String description,
    String begin, String end, String type, String id_O) async {
  try {
    var url = Uri.http('e-vote.x10.mx', '/setElection.php');
    url.toString();
    var response = await http.post(url, body: {
      'code': code,
      'nom': nom,
      'description': description,
      'begin': begin,
      'end': end,
      'id_O': id_O,
      'type': type
    });
    return true;
  } catch (e) {
    Fluttertoast.showToast(msg: "Un problème s'est posé, $e");
    print("api_DB: $e");
  }
  return false;
}

Future<dynamic> inscritCandidat(String nom, String prenom) async {
  try {
    var url = Uri.http('e-vote.x10.mx', '/setCandidat.php');
    url.toString();
    var response = await http.post(url, body: {'nom': nom, 'prenom': prenom});
    if (response.statusCode == 200) {
      // Si la réponse est correcte, parsez le contenu de la réponse en JSON
      final data = json.decode(response.body);
      return data;
    } else {
      // Si la réponse est incorrecte, affichez l'erreur
      print(response.statusCode);
      Fluttertoast.showToast(msg: "Un problème s'est posé, merci de réessayer");
      return null;
    }
  } catch (e) {
    Fluttertoast.showToast(msg: "Un problème s'est posé, $e");
    print("api_DB: $e");
  }
  return false;
}

Future<dynamic> getCandidatByName(String nom, String prenom) async {
  var url = Uri.http('e-vote.x10.mx', '/getCandidatByName.php');
  url.toString();
  try {
    var response = await http.post(url, body: {'nom': nom, 'prenom': prenom});
    if (response.statusCode == 200) {
      // Si la réponse est correcte, parsez le contenu de la réponse en JSON
      final data = json.decode(response.body);
      //print(data);

      return data;
    } else {
      // Si la réponse est incorrecte, affichez l'erreur
      print(response.statusCode);
      Fluttertoast.showToast(msg: "Un problème s'est posé, merci de réessayer");
      return null;
    }
  } catch (e) {
    Fluttertoast.showToast(msg: "Un problème s'est posé, $e");
    print("api_DB: $e");

    return null;
  }
}

Future<dynamic> inscritCandidatToElection(String code, String id_C) async {
  try {
    var url = Uri.http('e-vote.x10.mx', '/setCandidatToElection.php');
    url.toString();
    print("$code => $id_C");
    var response = await http.post(url, body: {'code': code, 'id_C': id_C});
    final data = json.decode(response.body);
    //print(data);

    return data;
  } catch (e) {
    Fluttertoast.showToast(msg: "Un problème s'est posé, $e");
    print("api_DB: $e");
  }
  return false;
}

Future<dynamic> inscritElecteurToElectionPrive(
    String id_epv, String code, String email) async {
  try {
    var url = Uri.http('e-vote.x10.mx', '/setElecteurToElectionPrive.php');
    url.toString();
    var response = await http
        .post(url, body: {'id_epv': id_epv, 'email': email, 'code': code});
    return true;
  } catch (e) {
    Fluttertoast.showToast(msg: "Un problème s'est posé, $e");
    print("api_DB: $e");
  }
  return false;
}

Future<dynamic> getAllElectionToOrganisateur(String id_O) async {
  try {
    var url = Uri.http('e-vote.x10.mx', '/getAllElectionToOrganisateur.php');
    url.toString();
    var response = await http.post(url, body: {'id_O': id_O});
    if (response.statusCode == 200) {
      // Si la réponse est correcte, parsez le contenu de la réponse en JSON
      final data = json.decode(response.body);
      //print(data);

      return data;
    } else {
      // Si la réponse est incorrecte, affichez l'erreur
      print(response.statusCode);
      Fluttertoast.showToast(msg: "Un problème s'est posé, merci de réessayer");
      return null;
    }
  } catch (e) {
    Fluttertoast.showToast(msg: "Un problème s'est posé, $e");
    print("api_DB: $e");
  }
  return false;
}

Future<dynamic> getElecteurPriveById(String id_epv) async {
  try {
    var url = Uri.http('e-vote.x10.mx', '/getElecteurPriveById.php');
    url.toString();
    var response = await http.post(url, body: {'id_epv': id_epv});
    if (response.statusCode == 200) {
      // Si la réponse est correcte, parsez le contenu de la réponse en JSON
      final data = json.decode(response.body);
      //print(data);

      return data;
    } else {
      // Si la réponse est incorrecte, affichez l'erreur
      print(response.statusCode);
      Fluttertoast.showToast(msg: "Un problème s'est posé, merci de réessayer");
      return null;
    }
  } catch (e) {
    Fluttertoast.showToast(msg: "Un problème s'est posé, $e");
    print("api_DB: $e");
  }
  return false;
}

Future<dynamic> getElection(String code) async {
  try {
    var url = Uri.http('e-vote.x10.mx', '/getElection.php');
    url.toString();
    var response = await http.post(url, body: {'code': code});
    if (response.statusCode == 200) {
      // Si la réponse est correcte, parsez le contenu de la réponse en JSON
      final data = json.decode(response.body);
      //print(data);

      return data;
    } else {
      // Si la réponse est incorrecte, affichez l'erreur
      print(response.statusCode);
      Fluttertoast.showToast(msg: "Un problème s'est posé, merci de réessayer");
      return null;
    }
  } catch (e) {
    Fluttertoast.showToast(msg: "Un problème s'est posé, $e");
    print("api_DB: $e");
  }
  return false;
}

Future<dynamic> getElecteurByElection(String code) async {
  try {
    var url = Uri.http('e-vote.x10.mx', '/getElecteurPrive.php');
    url.toString();
    var response = await http.post(url, body: {'code': code});
    if (response.statusCode == 200) {
      // Si la réponse est correcte, parsez le contenu de la réponse en JSON
      final data = json.decode(response.body);
      //print(data);

      return data;
    } else {
      // Si la réponse est incorrecte, affichez l'erreur
      print(response.statusCode);
      Fluttertoast.showToast(msg: "Un problème s'est posé, merci de réessayer");
      return null;
    }
  } catch (e) {
    Fluttertoast.showToast(msg: "Un problème s'est posé, $e");
    print("api_DB: $e");
  }
  return false;
}

Future<dynamic> getElecteurToElecctionPublic(String email) async {
  try {
    var url = Uri.http('e-vote.x10.mx', '/getElecteurPublic.php');
    url.toString();
    var response = await http.post(url, body: {'email': email});
    if (response.statusCode == 200) {
      // Si la réponse est correcte, parsez le contenu de la réponse en JSON
      final data = json.decode(response.body);
      //print(data);

      return data;
    } else {
      // Si la réponse est incorrecte, affichez l'erreur
      print(response.statusCode);
      Fluttertoast.showToast(msg: "Un problème s'est posé, merci de réessayer");
      return null;
    }
  } catch (e) {
    Fluttertoast.showToast(msg: "Un problème s'est posé, $e");
    print("api_DB: $e");
  }
  return false;
}

Future<dynamic> setElecteurPublic(String email) async {
  try {
    var url = Uri.http('e-vote.x10.mx', '/setElecteurToElectionPublic.php');
    url.toString();
    var response = await http.post(url, body: {'email': email});
    if (response.statusCode == 200) {
      // Si la réponse est correcte, parsez le contenu de la réponse en JSON
      final data = json.decode(response.body);
      //print(data);

      return data;
    } else {
      // Si la réponse est incorrecte, affichez l'erreur
      print(response.statusCode);
      Fluttertoast.showToast(msg: "Un problème s'est posé, merci de réessayer");
      return null;
    }
  } catch (e) {
    Fluttertoast.showToast(msg: "Un problème s'est posé, $e");
    print("api_DB: $e");
  }
  return false;
}

Future<dynamic> setMarqueElecteurPublic(String code, String id_epb) async {
  try {
    var url = Uri.http('e-vote.x10.mx', '/setMarqueElecteurPublic.php');
    url.toString();
    var response = await http.post(url, body: {'code': code, 'id_epb': id_epb});
    if (response.statusCode == 200) {
      // Si la réponse est correcte, parsez le contenu de la réponse en JSON
      final data = json.decode(response.body);
      //print(data);

      return data;
    } else {
      // Si la réponse est incorrecte, affichez l'erreur
      print(response.statusCode);
      Fluttertoast.showToast(msg: "Un problème s'est posé, merci de réessayer");
      return null;
    }
  } catch (e) {
    Fluttertoast.showToast(msg: "Un problème s'est posé, $e");
    print("api_DB: $e");
  }
  return false;
}

Future<dynamic> setMarqueElecteurPrive(String id_epv) async {
  try {
    var url = Uri.http('e-vote.x10.mx', '/setMarqueElecteurPrive.php');
    url.toString();
    var response = await http.post(url, body: {'id_epv': id_epv});
    if (response.statusCode == 200) {
      // Si la réponse est correcte, parsez le contenu de la réponse en JSON
      final data = json.decode(response.body);
      //print(data);

      return data;
    } else {
      // Si la réponse est incorrecte, affichez l'erreur
      print(response.statusCode);
      Fluttertoast.showToast(msg: "Un problème s'est posé, merci de réessayer");
      return null;
    }
  } catch (e) {
    Fluttertoast.showToast(msg: "Un problème s'est posé, $e");
    print("api_DB: $e");
  }
  return false;
}

Future<dynamic> getCandidatToElection(String code) async {
  try {
    var url = Uri.http('e-vote.x10.mx', '/getCandidatToElection.php');
    url.toString();
    var response = await http.post(url, body: {'code': code});
    if (response.statusCode == 200) {
      // Si la réponse est correcte, parsez le contenu de la réponse en JSON
      final data = json.decode(response.body);
      //print(data);

      return data;
    } else {
      // Si la réponse est incorrecte, affichez l'erreur
      print(response.statusCode);
      Fluttertoast.showToast(msg: "Un problème s'est posé, merci de réessayer");
      return null;
    }
  } catch (e) {
    Fluttertoast.showToast(msg: "Un problème s'est posé, $e");
    print("api_DB: $e");
  }
  return false;
}

Future<dynamic> getCandidat(String id_C) async {
  try {
    var url = Uri.http('e-vote.x10.mx', '/getCandidat.php');
    url.toString();
    var response = await http.post(url, body: {'id_C': id_C});
    if (response.statusCode == 200) {
      // Si la réponse est correcte, parsez le contenu de la réponse en JSON
      final data = json.decode(response.body);
      //print(data);

      return data;
    } else {
      // Si la réponse est incorrecte, affichez l'erreur
      print(response.statusCode);
      Fluttertoast.showToast(msg: "Un problème s'est posé, merci de réessayer");
      return null;
    }
  } catch (e) {
    Fluttertoast.showToast(msg: "Un problème s'est posé, $e");
    print("api_DB: $e");
  }
  return false;
}

Future<dynamic> getElecteurPublic(String email) async {
  try {
    var url = Uri.http('e-vote.x10.mx', '/getElecteurPublic.php');
    url.toString();
    var response = await http.post(url, body: {'email': email});
    if (response.statusCode == 200) {
      // Si la réponse est correcte, parsez le contenu de la réponse en JSON
      final data = json.decode(response.body);
      //print(data);

      return data;
    } else {
      // Si la réponse est incorrecte, affichez l'erreur
      print(response.statusCode);
      Fluttertoast.showToast(msg: "Un problème s'est posé, merci de réessayer");
      return null;
    }
  } catch (e) {
    Fluttertoast.showToast(msg: "Un problème s'est posé, $e");
    print("api_DB: $e");
  }
  return false;
}

Future<dynamic> getElecteurPublicMarquer(String code, String id_epb) async {
  try {
    var url = Uri.http('e-vote.x10.mx', '/getElecteurPublicMarquer.php');
    url.toString();
    var response = await http.post(url, body: {'code': code, 'id_epb': id_epb});
    if (response.statusCode == 200) {
      // Si la réponse est correcte, parsez le contenu de la réponse en JSON
      final data = json.decode(response.body);
      //print(data);

      return data;
    } else {
      // Si la réponse est incorrecte, affichez l'erreur
      print(response.statusCode);
      Fluttertoast.showToast(msg: "Un problème s'est posé, merci de réessayer");
      return null;
    }
  } catch (e) {
    Fluttertoast.showToast(msg: "Un problème s'est posé, $e");
    print("api_DB: $e");
  }
  return false;
}

Future<dynamic> updateVoixCandidatToElection(
    String code, String id_C, String voix) async {
  try {
    var url = Uri.http('e-vote.x10.mx', '/updateVoixCandidatToElection.php');
    url.toString();
    var response =
        await http.post(url, body: {'voix': voix, 'code': code, 'id_C': id_C});
    if (response.statusCode == 200) {
      // Si la réponse est correcte, parsez le contenu de la réponse en JSON
      final data = json.decode(response.body);
      //print(data);

      return data;
    } else {
      // Si la réponse est incorrecte, affichez l'erreur
      print(response.statusCode);
      Fluttertoast.showToast(msg: "Un problème s'est posé, merci de réessayer");
      return null;
    }
  } catch (e) {
    Fluttertoast.showToast(msg: "Un problème s'est posé, $e");
    print("api_DB: $e");
  }
  return false;
}

Future<dynamic> getVoixCandidatToElection(String code, String id_C) async {
  try {
    var url = Uri.http('e-vote.x10.mx', '/getVoixCandidatToElection.php');
    url.toString();
    var response = await http.post(url, body: {'code': code, 'id_C': id_C});
    if (response.statusCode == 200) {
      // Si la réponse est correcte, parsez le contenu de la réponse en JSON
      final data = json.decode(response.body);
      //print(data);

      return data;
    } else {
      // Si la réponse est incorrecte, affichez l'erreur
      print(response.statusCode);
      Fluttertoast.showToast(msg: "Un problème s'est posé, merci de réessayer");
      return null;
    }
  } catch (e) {
    Fluttertoast.showToast(msg: "Un problème s'est posé, $e");
    print("api_DB: $e");
  }
  return false;
}

Future<dynamic> getNbrElecteurToElectionPublic(String code) async {
  try {
    var url = Uri.http('e-vote.x10.mx', '/getNbrElecteurToElectionPublic.php');
    url.toString();
    var response = await http.post(url, body: {'code': code});
    if (response.statusCode == 200) {
      // Si la réponse est correcte, parsez le contenu de la réponse en JSON
      final data = json.decode(response.body);
      return data;
    } else {
      // Si la réponse est incorrecte, affichez l'erreur
      print(response.statusCode);
      Fluttertoast.showToast(msg: "Un problème s'est posé, merci de réessayer");
      return null;
    }
  } catch (e) {
    Fluttertoast.showToast(msg: "Un problème s'est posé, $e");
    print("api_DB: $e");
  }
  return false;
}

Future<dynamic> getNbrElecteurToElectionPrive(String code) async {
  try {
    var url = Uri.http('e-vote.x10.mx', '/getNbrElecteurToElectionPrive.php');
    url.toString();
    var response = await http.post(url, body: {'code': code});
    if (response.statusCode == 200) {
      // Si la réponse est correcte, parsez le contenu de la réponse en JSON
      final data = json.decode(response.body);
      return data;
    } else {
      // Si la réponse est incorrecte, affichez l'erreur
      print(response.statusCode);
      Fluttertoast.showToast(msg: "Un problème s'est posé, merci de réessayer");
      return null;
    }
  } catch (e) {
    Fluttertoast.showToast(msg: "Un problème s'est posé, $e");
    print("api_DB: $e");
  }
  return false;
}

Future<dynamic> deleteElection(String code) async {
  try {
    var delElecteurPrive =
        Uri.http('e-vote.x10.mx', '/deleteElecteurByElectionPrive.php');
    var delElecteurPublic =
        Uri.http('e-vote.x10.mx', '/deleteElecteurByElectionPublic.php');
    var delCandidat =
        Uri.http('e-vote.x10.mx', '/deleteCandidatByElection.php');
    var delElection = Uri.http('e-vote.x10.mx', '/deleteElection.php');

    getElection(code).then((election) {
      print(election);
      if (election["type"] == "Public") {
        http.post(delElecteurPublic, body: {'code': code}).then((val) {
          print(json.decode(val.body));
          http.post(delCandidat, body: {'code': code}).then((value) {
            print(json.decode(value.body));
            http.post(delElection, body: {'code': code}).then((value) {
              print(json.decode(value.body));
              return true;
            });
          });
        });
      } else {
        http.post(delElecteurPrive, body: {'code': code}).then((val) {
          http.post(delCandidat, body: {'code': code}).then((value) {
            http.post(delElection, body: {'code': code}).then((value) {
              return true;
            });
          });
        });
      }
    });
  } catch (e) {
    Fluttertoast.showToast(msg: "Un problème s'est posé, $e");
    print("api_DB: $e");
  }
  return false;
}

Future<dynamic> updateOrganisateur(String id_O, String nom, String prenom,
    String email, String password) async {
  try {
    var url = Uri.http('e-vote.x10.mx', '/updateOrganisateur.php');
    url.toString();
    var response = await http.post(url, body: {
      'id_O': id_O,
      'nom': nom,
      'prenom': prenom,
      'email': email,
      'password': password,
    });
    if (response.statusCode == 200) {
      // Si la réponse est correcte, parsez le contenu de la réponse en JSON
      final data = json.decode(response.body);
      print(data);
      return data;
    } else {
      // Si la réponse est incorrecte, affichez l'erreur
      print(response.statusCode);
      Fluttertoast.showToast(msg: "Un problème s'est posé, merci de réessayer");
      return null;
    }
  } catch (e) {
    Fluttertoast.showToast(msg: "Un problème s'est posé, $e");
    print("api_DB: $e");
  }
  return false;
}
