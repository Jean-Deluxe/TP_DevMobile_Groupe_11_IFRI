import 'dart:convert';
import 'dart:io';

Future<List<List<dynamic>>> convertCSVtoList(File file) async {
  List<List<dynamic>> result = [];
  var lines = await file.readAsLines();
  for (var line in lines) {
    var row = line.split(',');
    result.add(row.map((item) => item as dynamic).toList());
  }
  return result;
}
