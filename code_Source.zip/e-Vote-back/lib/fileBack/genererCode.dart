import 'dart:convert';
import 'dart:math';
import 'package:crypto/crypto.dart';

String genererCode() {
  final random = Random();
  final code = sha1
      .convert(utf8.encode(
          DateTime.now().toString() + random.nextInt(1000000).toString()))
      .toString()
      .substring(0, 6);
  return code;
}

String genererCodeRecuperation() {
  final random = Random();
  final code = sha1
      .convert(utf8.encode(
          DateTime.now().toString() + random.nextInt(1000000).toString()))
      .toString()
      .substring(0, 5);
  return code;
}
