import 'dart:io';

import 'package:fluttertoast/fluttertoast.dart';
import 'package:mailer/mailer.dart';
import 'package:mailer/smtp_server.dart';

sendMailInvitation(
    String email, String code, String identifiant, String dateFin) async {
  String username = "evotegrp11@gmail.com";
  String password = "mabpwlcjhwgczkrj";

  final smtpServer = gmail(username, password);

  // Create our message.
  final message = Message()
    ..from = Address(username)
    ..recipients.add(email)
    //..ccRecipients.addAll(['destCc1@example.com', 'destCc2@example.com'])
    // ..bccRecipients.add(Address('cedricabionan65@gmail.com'))
    ..subject = 'eVote-Invitation'
    // ..text = 'This is the plain text.\nThis is line 2 of the text part.'
    ..html =
        "<h1 style=\"color: #44a8fa;font-size: xxx-large; text-align:center\">eVote</h1> <p style=\"line-height: 2;text-align:center\">Vous avez été selectionné pour participer à une election. <br>    Voyez ci-dessous les informations qui vous permettront de voter: <br>    <span>Code du Vote: </span> <span style=\"font-weight: bold;\">$code</span><br>    <span>Identifiant: </span> <span style=\"font-weight: bold;\">$identifiant</span></p><p style=\"color: red;\">Merci d'effectuer votre vote avant le $dateFin</p>";

  try {
    final sendReport = await send(message, smtpServer);
    print('Message envoyé: ' + sendReport.toString());
  } on MailerException catch (e) {
    print(e.toString());
    for (var p in e.problems) {
      Fluttertoast.showToast(msg: "Un problème s'est posé, ${p.msg}");
      print('Problem: ${p.code}: ${p.msg}');
    }
  } on SocketException catch (e) {
    print(e.toString());
    Fluttertoast.showToast(
        msg: "Un problème s'est posé, l'envoi de mail a échoué");
    print('Problem: Manque de connexion ');
  }
}
