import 'package:fluttertoast/fluttertoast.dart';
import 'package:mailer/mailer.dart';
import 'package:mailer/smtp_server.dart';

sendMailRecuperation(String email, String code) async {
  String username = "evotegrp11@gmail.com";
  String password = "mabpwlcjhwgczkrj";

  final smtpServer = gmail(username, password);

  // Create our message.
  final message = Message()
    ..from = Address(username)
    ..recipients.add(email)
    //..ccRecipients.addAll(['destCc1@example.com', 'destCc2@example.com'])
    // ..bccRecipients.add(Address('cedricabionan65@gmail.com'))
    ..subject = 'eVote-Récuperation'
    // ..text = 'This is the plain text.\nThis is line 2 of the text part.'
    ..html =
        "<h1 style=\"color: #44a8fa; text-align:center\">eVote</h1><p style=\"text-align:center\">Votre code de recupération est :</p><h2 style=\"text-align:center;\">$code</h2>";

  try {
    final sendReport = await send(message, smtpServer);
    Fluttertoast.showToast(msg: "Mail envoyé avec succès");

    print('Message envoyé: ' + sendReport.toString());
  } on MailerException catch (e) {
    Fluttertoast.showToast(msg: "Un problème s'est posé, merci de réessayer");
    print(e.toString());
    for (var p in e.problems) {
      Fluttertoast.showToast(
          msg: "Un problème s'est posé pour l'envoie du mail, ${p.msg}");
      print('Problem: ${p.code}: ');
    }
  }
}
