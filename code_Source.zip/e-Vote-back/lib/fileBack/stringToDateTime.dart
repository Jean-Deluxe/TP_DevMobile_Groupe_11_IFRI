DateTime stringToDateTime(String date) {
  var brut = date.toString().split('-');
  var tmp1 = brut[2].split(' ');
  var tmp2 = tmp1[1].split(':');
  var y = int.parse(brut[0]);
  var m = int.parse(brut[1]);
  var d = int.parse(tmp1[0]);
  var h = int.parse(tmp2[0]);
  var mn = int.parse(tmp2[1]);
  var s = int.parse(tmp2[2]);
  return DateTime(y, m, d, h, mn, s);
}
