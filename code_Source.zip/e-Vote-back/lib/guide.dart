import 'package:e_vote/modifiProfil.dart';
import 'package:flutter/material.dart';

import 'main.dart';

class Guide extends StatefulWidget {
  const Guide({Key? key}) : super(key: key);

  @override
  State<Guide> createState() => _GuideState();
}

class _GuideState extends State<Guide> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Guide",
          style: TextStyle(
              color: Color(0xFF2F80F7),
              fontSize: 30,
              fontWeight: FontWeight.bold),
          textAlign: TextAlign.center,
        ),
        centerTitle: true,
        backgroundColor: const Color(0xFFE4E8E9),
        foregroundColor: Color(0xFF2F80F7),
        elevation: 0,
      ),
      body: Container(
          height: MediaQuery.of(context).size.height,
          color: const Color(0xFFE4E8E9),
          padding: const EdgeInsets.all(20),
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: ClipOval(
                    child: Image.asset(
                      "assets/voter.png",
                      width: 100,
                      height: 100,
                    ),
                  ),
                ),
                Divider(),
                option("1-Comment utilisé e-vote?",
                    "L'ouverture de l'application e-Vote vous présente deux(2)possibilités d'utilisation: la création d'un vote et la participation à un vote. Pour créer un vote, l’organisateur doit s’assurer d’avoir la liste des candidats en deux colonnes (Nom et Prénom) sans mettre de titre à ce document. Ce fichier doit être au format .csv. Egalement s’assurer d’avoir la lsite des électeurs (comportant uniquement les emails) au même format (csv), si le type de vote qui sera créé est privé."),
                option("2-Comment créé un vote?",
                    "Il faut au préalable que vous ayez un compte crée sur l'application,connectez vous ensuite et choisissez l'option \"créer un vote\". Vous remplissez les informations concernant le vote(intitulé du vote, description du vote, type de vote, candidats, électeurs…) que vous validez. Après la création du vote, vous n'aurez qu'à suivre l'évolution du vote(statistiques, délai…). "),
                option("3-Comment voter?",
                    "L'option \"voter\" ne nécessite pas obligatoirement l'existence d'un compte. Dès que vous choisissez l'option \"voter\",vous avez accès à la description du vote(à lire attentivement)puis vous passez au vote proprement dit en choisissant votre candidat dans la liste présentée que vous confirmerez. "),
              ],
            ),
          )),
    );
  }
}

Widget option(String titre, String body) {
  return Padding(
    padding: const EdgeInsets.all(10.0),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(titre,
            style: TextStyle(
                color: Color(0xFF2F80F7),
                fontSize: 20,
                fontWeight: FontWeight.bold)),
        Text(
          body,
          style: TextStyle(fontSize: 15),
        ),
      ],
    ),
  );
}
