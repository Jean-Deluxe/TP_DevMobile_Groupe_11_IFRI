import 'package:e_vote/fileBack/api_DB.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:e_vote/acceuil.dart';
import 'package:e_vote/connexion.dart';

class Inscription extends StatefulWidget {
  const Inscription({Key? key}) : super(key: key);

  @override
  State<Inscription> createState() => _InscriptionState();
}

class _InscriptionState extends State<Inscription> {
  final nameController = TextEditingController();
  final lastnameController = TextEditingController();
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  final password2Controller = TextEditingController();
  final formKey = GlobalKey<FormState>();
  final form = GlobalKey<FormState>();

  bool ok = false;
  bool isObscure2 = true;
  bool isObscure = true;
  bool check = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text(
            "",
            style: TextStyle(
                color: Color(0xFF2F80F7),
                fontSize: 30,
                fontWeight: FontWeight.bold),
            textAlign: TextAlign.center,
          ),
          centerTitle: true,
          backgroundColor: const Color(0xFFE4E8E9),
          foregroundColor: Color(0xFF2F80F7),
          elevation: 0,
        ),
        body: Container(
            height: MediaQuery.of(context).size.height,
            width: MediaQuery.of(context).size.width,
            decoration: const BoxDecoration(color: Color(0xFFE4E8E9)),
            child: SingleChildScrollView(
              child: Container(
                margin: const EdgeInsets.only(bottom: 80),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Center(
                      child: Image.asset(
                        "assets/voter.png",
                        height: MediaQuery.of(context).size.height * 0.2,
                        width: MediaQuery.of(context).size.width * 0.2,
                        alignment: Alignment.center,
                      ),
                    ),
                    const Text(
                      "Inscription",
                      style: TextStyle(
                          fontSize: 30,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF2F80F7)),
                    ),
                    const SizedBox(height: 35),
                    Form(
                      key: formKey,
                      child: Column(
                        children: <Widget>[
                          Container(
                            margin: const EdgeInsets.symmetric(horizontal: 30),
                            child: TextFormField(
                                controller: nameController,
                                keyboardType: TextInputType.text,
                                textInputAction: TextInputAction.done,
                                textAlign: TextAlign.start,
                                decoration: const InputDecoration(
                                  filled: true,
                                  prefixIcon: Icon(
                                    Icons.person_pin_sharp,
                                    size: 25,
                                    color: Colors.black,
                                  ),
                                  labelText: 'Nom',
                                  labelStyle: TextStyle(
                                    color: Colors.black,
                                  ),
                                  border: OutlineInputBorder(
                                    borderRadius:
                                        BorderRadius.all(Radius.circular(8.0)),
                                    borderSide: BorderSide(color: Colors.black),
                                  ),
                                ),
                                style: const TextStyle(color: Colors.black),
                                cursorColor: Colors.black,
                                cursorHeight: 20,
                                validator: (value) {
                                  return (value == null || value == "")
                                      ? "Ce champ est obligatoire"
                                      : null;
                                }),
                          ),
                          const SizedBox(height: 10),
                          Container(
                            margin: const EdgeInsets.symmetric(horizontal: 30),
                            child: TextFormField(
                                controller: lastnameController,
                                keyboardType: TextInputType.text,
                                textInputAction: TextInputAction.done,
                                textAlign: TextAlign.start,
                                decoration: const InputDecoration(
                                  filled: true,
                                  prefixIcon: Icon(
                                    Icons.person_pin_sharp,
                                    size: 25,
                                    color: Colors.black,
                                  ),
                                  labelText: 'Prénoms',
                                  labelStyle: TextStyle(
                                    color: Colors.black,
                                  ),
                                  border: OutlineInputBorder(
                                    borderRadius:
                                        BorderRadius.all(Radius.circular(8.0)),
                                    borderSide: BorderSide(color: Colors.black),
                                  ),
                                ),
                                style: const TextStyle(color: Colors.black),
                                cursorColor: Colors.black,
                                cursorHeight: 20,
                                validator: (value) {
                                  return (value == null || value == "")
                                      ? "Ce champ est obligatoire"
                                      : null;
                                }),
                          ),
                          const SizedBox(height: 10),
                          Container(
                            margin: const EdgeInsets.symmetric(horizontal: 30),
                            child: TextFormField(
                                controller: emailController,
                                keyboardType: TextInputType.emailAddress,
                                textInputAction: TextInputAction.done,
                                textAlign: TextAlign.start,
                                decoration: const InputDecoration(
                                  filled: true,
                                  prefixIcon: Icon(
                                    Icons.mail_outline,
                                    size: 25,
                                    color: Colors.black,
                                  ),
                                  labelText: 'Email',
                                  labelStyle: TextStyle(
                                    color: Colors.black,
                                  ),
                                  border: OutlineInputBorder(
                                    borderRadius:
                                        BorderRadius.all(Radius.circular(8.0)),
                                    borderSide: BorderSide(color: Colors.black),
                                  ),
                                ),
                                style: const TextStyle(color: Colors.black),
                                cursorColor: Colors.black,
                                showCursor: true,
                                validator: (value) {
                                  if (value!.isEmpty) {
                                    return 'Ce champ est obligatoire';
                                  }
                                  if (!value.contains("@")) {
                                    return "L'email doit contenir @";
                                  }
                                  if (check) {
                                    print("ici $check");
                                    return "Ce mail existe déjà";
                                  }

                                  return null;
                                }),
                          ),
                          const SizedBox(height: 10),
                          Container(
                            margin: const EdgeInsets.symmetric(horizontal: 30),
                            child: TextFormField(
                                obscureText: isObscure,
                                controller: passwordController,
                                keyboardType: TextInputType.text,
                                textAlign: TextAlign.start,
                                decoration: InputDecoration(
                                  filled: true,
                                  suffixIcon: IconButton(
                                    hoverColor: Colors.transparent,
                                    splashColor: Colors.transparent,
                                    icon: Icon(isObscure
                                        ? Icons.visibility_off
                                        : Icons.visibility_sharp),
                                    onPressed: () {
                                      setState(() {
                                        isObscure = !isObscure;
                                      });
                                    },
                                  ),
                                  prefixIcon: const Icon(
                                    Icons.lock,
                                    size: 25,
                                    color: Colors.black,
                                  ),
                                  labelText: 'Mot de passe',
                                  labelStyle: const TextStyle(
                                    color: Colors.black,
                                  ),
                                  border: const OutlineInputBorder(
                                    borderRadius:
                                        BorderRadius.all(Radius.circular(8.0)),
                                    borderSide: BorderSide(color: Colors.black),
                                  ),
                                ),
                                style: const TextStyle(color: Colors.black),
                                cursorColor: Colors.black,
                                validator: (value) {
                                  RegExp regex = RegExp(
                                      r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{8,}$');
                                  var val = value ?? "";
                                  if (val.isEmpty) {
                                    return 'Ce champ est obligatoire';
                                  } else if (val.length < 7) {
                                    return "Le mot de passe doit contenir au moins 8 caractères";
                                  }
                                  return null;
                                }),
                          ),
                          const SizedBox(height: 10),
                          Container(
                            margin: const EdgeInsets.symmetric(horizontal: 30),
                            child: TextFormField(
                                obscureText: isObscure2,
                                controller: password2Controller,
                                keyboardType: TextInputType.text,
                                textAlign: TextAlign.start,
                                decoration: InputDecoration(
                                  filled: true,
                                  suffixIcon: IconButton(
                                    hoverColor: Colors.transparent,
                                    splashColor: Colors.transparent,
                                    icon: Icon(isObscure2
                                        ? Icons.visibility_off
                                        : Icons.visibility_sharp),
                                    onPressed: () {
                                      setState(() {
                                        isObscure2 = !isObscure2;
                                      });
                                    },
                                  ),
                                  prefixIcon: const Icon(
                                    Icons.lock_outline,
                                    size: 25,
                                    color: Colors.black,
                                  ),
                                  labelText: 'Confirmation du mot de passe',
                                  labelStyle: const TextStyle(
                                    color: Colors.black,
                                  ),
                                  border: const OutlineInputBorder(
                                    borderRadius:
                                        BorderRadius.all(Radius.circular(8.0)),
                                    borderSide: BorderSide(color: Colors.black),
                                  ),
                                ),
                                style: const TextStyle(color: Colors.black),
                                cursorColor: Colors.black,
                                cursorHeight: 20,
                                validator: (value) {
                                  if (value!.isEmpty) {
                                    return 'Ce champ est obligatoire';
                                  }
                                  if (value != passwordController.text) {
                                    return "Le mot de passe n'est pas identique";
                                  }
                                  return null;
                                }),
                          ),
                          const SizedBox(height: 20),
                          FormField<bool>(
                            //key: form,
                            builder: (state) {
                              return Container(
                                margin:
                                    const EdgeInsets.symmetric(horizontal: 25),
                                child: Row(
                                  children: [
                                    Checkbox(
                                        value: ok,
                                        checkColor: Colors.white,
                                        onChanged: (bool? a) {
                                          setState(() {
                                            ok = a!;
                                          });
                                        }),
                                    Container(
                                      width: MediaQuery.of(context).size.width *
                                          0.7,
                                      child: const Text(
                                        "En cliquant,vous acceptez nos conditions d'utilisation de l'application",
                                        style: TextStyle(
                                          color: Colors.black,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              );
                            },
                            validator: (value) {
                              if (!ok) {
                                return "Vous devez d'abord accepter nos conditions d'utilisation ";
                              }
                              return null;
                            },
                          ),
                          const SizedBox(height: 20),
                          Container(
                            width: 150,
                            child: ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(10)),
                                  primary: Colors.blue[900],
                                  elevation: 5),
                              onPressed: () {
                                getOrganisateurByEmail(emailController.text)
                                    .then((compte) {
                                  if (compte.runtimeType != bool) {
                                    check = true;
                                  } else {
                                    check = false;
                                  }
                                  if (formKey.currentState!.validate()) {
                                    check = false;
                                    String nom = nameController.text;
                                    String prenom = lastnameController.text;
                                    String email = emailController.text;
                                    String password = passwordController.text;
                                    print("Hey");
                                    try {
                                      inscritOrganisateur(
                                          nom, prenom, email, password);
                                      nameController.text = "";
                                      lastnameController.text = "";
                                      emailController.text = "";
                                      passwordController.text = "";
                                      password2Controller.text = "";
                                      ok = false;
                                      isObscure2 = true;
                                      isObscure = true;
                                      check = false;
                                      Navigator.of(context).push(
                                        MaterialPageRoute(
                                          builder: (ctx) {
                                            return const Connexion();
                                          },
                                        ),
                                      );
                                    } catch (e) {
                                      print("Problème: ${e}");
                                    }
                                  } else {
                                    print("Proooobleme");
                                  }
                                });

                                setState(() {});
                              },
                              child: const Text(
                                "S'inscrire",
                                style: TextStyle(color: Colors.white),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            )));
  }
}
