import 'package:e_vote/fileBack/api_DB.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:e_vote/confirmationVote.dart';
import 'package:e_vote/partclass/cand.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ListCandidat extends StatefulWidget {
  const ListCandidat({Key? key}) : super(key: key);

  @override
  State<ListCandidat> createState() => _ListCandidatState();
}

class _ListCandidatState extends State<ListCandidat> {
  var code;
  dynamic listes;
  bool paus = true;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    load();
  }

  void load() {
    SharedPreferences.getInstance().then((value) {
      code = value.getString("code");
      print(value);
      getCandidatToElection(code).then((value) {
        setState(() {
          listes = value;
          paus = false;
        });
      });
    });
  }

  List<Widget> loadingListe() {
    List<Widget> candidats = <Widget>[];

    paus
        ? candidats.add(const CircularProgressIndicator(
            color: Colors.blueAccent,
          ))
        : null;
    if (candidats.isEmpty) {
      for (var candidat in listes) {
        candidats.add(
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 10),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
              ),
              height: MediaQuery.of(context).size.height * 0.28,
              width: MediaQuery.of(context).size.width * 0.38,
              child: ElevatedButton(
                onPressed: () {
                  SharedPreferences.getInstance().then((value) {
                    value.setInt('id_C', int.parse(candidat["id_C"]));
                  });
                  print(candidat["id_C"]);

                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (ctx) {
                        return const ConfirmationVote();
                      },
                    ),
                  );
                },
                style: ElevatedButton.styleFrom(
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                        side: const BorderSide(
                            color: Color(0xFF07FF66),
                            style: BorderStyle.solid,
                            width: 3)),
                    elevation: 25,
                    shadowColor: Color.fromARGB(255, 73, 12, 12)),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(90),
                      child: CircleAvatar(
                        radius: 50,
                        child: Center(
                          child: Image.asset(
                            "assets/profill.png",
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 4,
                    ),
                    Text(
                      candidat["nom"],
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(
                      height: 4,
                    ),
                    Text(
                      candidat["prenom"],
                      style: const TextStyle(),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      }
    }
    return candidats;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "La liste des candidats",
          style: TextStyle(
              color: Color(0xFF2F80F7),
              fontSize: 20,
              fontWeight: FontWeight.bold),
          textAlign: TextAlign.center,
        ),
        centerTitle: true,
        backgroundColor: const Color(0xFFE4E8E9),
        foregroundColor: Color(0xFF2F80F7),
        elevation: 0,
      ),
      body: Container(
        color: Color(0xFFE4E8E9),
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(vertical: 50),
          reverse: true,
          child: Flexible(
            flex: 2,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const SizedBox(height: 25),
                Container(
                  child: const Text(
                    'Choisissez votre candidat',
                    style: TextStyle(
                      fontSize: 20,
                      color: Colors.black,
                    ),
                  ),
                ),
                const SizedBox(
                  height: 20,
                ),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  reverse: true,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: loadingListe(),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 25),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
