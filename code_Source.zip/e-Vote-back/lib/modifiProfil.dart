import 'package:flutter/material.dart';

import 'main.dart';

class ModifiProfil extends StatefulWidget {
  const ModifiProfil({Key? key}) : super(key: key);

  @override
  State<ModifiProfil> createState() => _ModifiProfilState();
}

class _ModifiProfilState extends State<ModifiProfil> {
  @override
  final _formKey = GlobalKey<FormState>();
  final nameController = TextEditingController();
  final prenomController = TextEditingController();
  final professionController = TextEditingController();

  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
          padding: const EdgeInsets.all(20),
          child: SingleChildScrollView(
            child: Column(
              children: [
                Row(
                  children: const [
                    Icon(Icons.arrow_back),
                    Padding(
                      padding: EdgeInsets.only(left: 30),
                      child: Text(
                        "Ajouter un candidat",
                        style: TextStyle(
                          color: Color(0xFF2F80F7),
                          fontSize: 30,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 15.0),
                Center(
                  child: Image.asset("assets/index.jpeg"),
                ),
                const SizedBox(height: 25.0),
                Form(
                    key: _formKey,
                    child: Column(
                      children: [
                        TextFormField(
                          keyboardType: TextInputType.name,
                          controller: nameController,
                          decoration: const InputDecoration(
                              labelText: 'Nom',
                              hintText: 'Entrez votre nom',
                              icon: Icon(Icons.person)),
                          validator: (String? name) {
                            return (name == null || name == "")
                                ? "Ce champ est obligatoire"
                                : null;
                          },
                        ),
                        const SizedBox(height: 25.0),
                        TextFormField(
                          keyboardType: TextInputType.name,
                          controller: prenomController,
                          decoration: const InputDecoration(
                            labelText: 'Prénom',
                            hintText: 'Entrez votre nom et votre prénom',
                            icon: Icon(Icons.person),
                            iconColor: Colors.black,
                          ),
                          validator: (String? prenom) {
                            return (prenom == null || prenom == "")
                                ? "Ce champ est obligatoire"
                                : null;
                          },
                        ),
                        const SizedBox(height: 25.0),
                        TextFormField(
                          keyboardType: TextInputType.text,
                          obscureText: true,
                          controller: professionController,
                          decoration: const InputDecoration(
                            icon: Icon(Icons.work),
                            labelText: 'Profession',
                            hintText: 'Entrez votre profession',
                          ),
                          validator: (String? value) {
                            return (value == null || value == "")
                                ? "Ce champ est obligatoire"
                                : null;
                          },
                        ),
                        const SizedBox(height: 30.0),
                        Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              ElevatedButton(
                                onPressed: () {
                                  if (_formKey.currentState!.validate()) {}
                                },
                                style: ElevatedButton.styleFrom(
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(30.0),
                                  ),
                                  primary: const Color(0xFF2F80F7),
                                ),
                                child: const Text("Valider"),
                              ),
                            ]),
                      ],
                    )),
              ],
            ),
          )),
    );
  }
}
