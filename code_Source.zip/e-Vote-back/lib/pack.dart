import 'package:flutter/material.dart';
import 'package:e_vote/listCandidat.dart';
import 'package:e_vote/Cours.dart';
import 'package:e_vote/confirmationVote.dart';
import 'package:e_vote/draw.dart';
import 'package:e_vote/acceuil.dart';
//import 'package:e_vote/intitul%C3%A9.dart';
import 'package:e_vote/connexion.dart';
import 'package:e_vote/chargement.dart';
import 'package:e_vote/codeRestauration.dart';
import 'package:e_vote/inscription.dart';
import 'package:e_vote/recuperation.dart';
import 'package:e_vote/voter.dart';

import 'detail.dart';
import 'dashbord.dart';
