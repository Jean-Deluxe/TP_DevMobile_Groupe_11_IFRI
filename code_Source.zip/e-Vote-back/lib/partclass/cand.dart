import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';

class Candidat {
  late String nom;
  late String prenom;

  Candidat({required this.nom, required this.prenom});

  int nbrcandidat() {
    return demoListCandidat.length;
  }

  @override
  String toString() {
    return nom;
  }
}

List<Candidat> demoListCandidat = [
  Candidat(nom: "KISS", prenom: "Daniel"),
  Candidat(nom: "TIWA", prenom: "Savage"),
  Candidat(nom: "DEMS", prenom: "Damso"),
  Candidat(nom: "STAR", prenom: "Patrick"),
  Candidat(nom: "REDA", prenom: "Yasso"),
  Candidat(nom: "BAYA", prenom: "Amy"),
];
