import 'dart:ffi';

import 'package:e_vote/partclass/cand.dart';

class Pourc {
  double pourcentage;
  Candidat candidat;
  Pourc({required this.pourcentage, required this.candidat});
}

List<Pourc> demoListPourc = [
  Pourc(pourcentage: 8, candidat: demoListCandidat[0]),
  Pourc(pourcentage: 40, candidat: demoListCandidat[1]),
  Pourc(pourcentage: 21, candidat: demoListCandidat[2]),
  Pourc(pourcentage: 2, candidat: demoListCandidat[3]),
  Pourc(pourcentage: 19, candidat: demoListCandidat[4]),
  Pourc(pourcentage: 10, candidat: demoListCandidat[5]),
];
