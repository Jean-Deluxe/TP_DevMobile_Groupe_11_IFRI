import 'package:e_vote/fileBack/api_DB.dart';
import 'package:e_vote/fileBack/genererCode.dart';
import 'package:e_vote/fileBack/mailRecuperation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:e_vote/codeRestauration.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Recuperation extends StatefulWidget {
  const Recuperation({Key? key}) : super(key: key);

  @override
  State<Recuperation> createState() => _RecuperationState();
}

class _RecuperationState extends State<Recuperation> {
  final emailController = TextEditingController();
  final formKey = GlobalKey<FormState>();
  bool compteExist = false;
  bool isload = false;
  var code;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Récupération",
          style: TextStyle(
              color: Color(0xFF2F80F7),
              fontSize: 30,
              fontWeight: FontWeight.bold),
          textAlign: TextAlign.center,
        ),
        centerTitle: true,
        backgroundColor: const Color(0xFFE4E8E9),
        foregroundColor: Color(0xFF2F80F7),
        elevation: 0,
      ),
      body: Container(
          //possss
          padding: const EdgeInsets.symmetric(vertical: 100),
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          decoration: const BoxDecoration(color: Color(0xFFE4E8E9)),
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const SizedBox(height: 80),
                Container(
                  margin: const EdgeInsets.symmetric(horizontal: 30),
                  child: const Text(
                    'Entrez le mail que vous aviez utilisé pour créer le compte',
                    style: TextStyle(fontSize: 15),
                  ),
                ),
                const SizedBox(
                  height: 50,
                ),
                Form(
                  key: formKey,
                  child: Column(
                    children: <Widget>[
                      Container(
                          margin: const EdgeInsets.symmetric(horizontal: 30),
                          child: TextFormField(
                            controller: emailController,
                            keyboardType: TextInputType.emailAddress,
                            autocorrect: true,
                            decoration: const InputDecoration(
                              labelText: "Email",
                              icon: Icon(
                                Icons.mail_outline,
                              ),
                            ),
                            validator: (value) {
                              if (value!.isEmpty) {
                                return 'Ce champ est obligatoire';
                              }
                              if (!value.contains("@")) {
                                return "L'email doit contenir @";
                              }
                              return null;
                            },
                          )),
                      const SizedBox(
                        height: 80,
                      ),
                      Container(
                        width: 150,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10)),
                              primary: Colors.blue[900],
                              elevation: 5),
                          onPressed: () async {
                            isload = true;
                            setState(() {});
                            var organisateur = await getOrganisateurByEmail(
                                emailController.text);
                            print(organisateur);
                            if (organisateur != null) {
                              if (organisateur.runtimeType != bool) {
                                if (formKey.currentState!.validate()) {
                                  code = genererCodeRecuperation();
                                  var email = emailController.text;
                                  sendMailRecuperation(email, code);
                                  final session =
                                      await SharedPreferences.getInstance();
                                  session.setString("codeRecuperation", code);
                                  session.setString("emailRecuperation", email);

                                  Navigator.of(context).push(
                                    MaterialPageRoute(
                                      builder: (ctx) {
                                        return const CodeRestauration();
                                      },
                                    ),
                                  );
                                }
                              } else {
                                Fluttertoast.showToast(
                                    msg: "Ce mail n'exist pas");
                                print("Ce mail n'exist pas");
                                //ce mail exist pas
                              }
                            }
                            isload = false;
                            setState(() {});
                          },
                          child: isload
                              ? const SizedBox(
                                  height: 20,
                                  width: 20,
                                  child: CircularProgressIndicator(
                                    color: Color.fromARGB(255, 255, 255, 255),
                                  ))
                              : const Text(
                                  "Envoyer",
                                  style: TextStyle(color: Colors.white),
                                ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          )),
    );
  }
}
