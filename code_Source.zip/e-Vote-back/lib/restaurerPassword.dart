import 'package:e_vote/connexion.dart';
import 'package:e_vote/fileBack/api_DB.dart';
import 'package:e_vote/fileBack/genererCode.dart';
import 'package:e_vote/fileBack/mailRecuperation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:e_vote/codeRestauration.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:shared_preferences/shared_preferences.dart';

class RestaurerPassword extends StatefulWidget {
  const RestaurerPassword({Key? key}) : super(key: key);

  @override
  State<RestaurerPassword> createState() => _RestaurerPasswordState();
}

class _RestaurerPasswordState extends State<RestaurerPassword> {
  final emailController = TextEditingController();
  final formKey = GlobalKey<FormState>();
  final passwordController = TextEditingController();
  final password2Controller = TextEditingController();
  bool isObscure2 = true;
  bool isObscure = true;
  bool compteExist = false;
  bool isload = false;
  var code;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Récupération",
          style: TextStyle(
              color: Color(0xFF2F80F7),
              fontSize: 30,
              fontWeight: FontWeight.bold),
          textAlign: TextAlign.center,
        ),
        centerTitle: true,
        backgroundColor: const Color(0xFFE4E8E9),
        foregroundColor: Color(0xFF2F80F7),
        elevation: 0,
      ),
      body: Container(
          //possss
          padding: const EdgeInsets.symmetric(vertical: 100),
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          decoration: const BoxDecoration(color: Color(0xFFE4E8E9)),
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const SizedBox(height: 80),
                Container(
                  margin: const EdgeInsets.symmetric(horizontal: 30),
                  child: const Text(
                    'Terminez la récupération de votre compte en remplissant les champs suivant',
                    style: TextStyle(fontSize: 15),
                  ),
                ),
                const SizedBox(
                  height: 50,
                ),
                Form(
                  key: formKey,
                  child: Column(
                    children: <Widget>[
                      const SizedBox(height: 10),
                      Container(
                        margin: const EdgeInsets.symmetric(horizontal: 30),
                        child: TextFormField(
                            obscureText: isObscure,
                            controller: passwordController,
                            keyboardType: TextInputType.text,
                            textAlign: TextAlign.start,
                            decoration: InputDecoration(
                              filled: true,
                              suffixIcon: IconButton(
                                hoverColor: Colors.transparent,
                                splashColor: Colors.transparent,
                                icon: Icon(isObscure
                                    ? Icons.visibility_off
                                    : Icons.visibility_sharp),
                                onPressed: () {
                                  setState(() {
                                    isObscure = !isObscure;
                                  });
                                },
                              ),
                              prefixIcon: const Icon(
                                Icons.lock,
                                size: 25,
                                color: Colors.black,
                              ),
                              labelText: 'Nouveau mot de passe',
                              labelStyle: const TextStyle(
                                color: Colors.black,
                              ),
                              border: const OutlineInputBorder(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(8.0)),
                                borderSide: BorderSide(color: Colors.black),
                              ),
                            ),
                            style: const TextStyle(color: Colors.black),
                            cursorColor: Colors.black,
                            validator: (value) {
                              RegExp regex = RegExp(
                                  r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{8,}$');
                              var val = value ?? "";
                              if (val.isEmpty) {
                                return 'Ce champ est obligatoire';
                              } else if (val.length < 7) {
                                return "Le mot de passe doit contenir au moins 8 caractères";
                              }
                              return null;
                            }),
                      ),
                      const SizedBox(height: 10),
                      Container(
                        margin: const EdgeInsets.symmetric(horizontal: 30),
                        child: TextFormField(
                            obscureText: isObscure2,
                            controller: password2Controller,
                            keyboardType: TextInputType.text,
                            textAlign: TextAlign.start,
                            decoration: InputDecoration(
                              filled: true,
                              suffixIcon: IconButton(
                                hoverColor: Colors.transparent,
                                splashColor: Colors.transparent,
                                icon: Icon(isObscure2
                                    ? Icons.visibility_off
                                    : Icons.visibility_sharp),
                                onPressed: () {
                                  setState(() {
                                    isObscure2 = !isObscure2;
                                  });
                                },
                              ),
                              prefixIcon: const Icon(
                                Icons.lock_outline,
                                size: 25,
                                color: Colors.black,
                              ),
                              labelText: 'Confirmez votre mot de passe',
                              labelStyle: const TextStyle(
                                color: Colors.black,
                              ),
                              border: const OutlineInputBorder(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(8.0)),
                                borderSide: BorderSide(color: Colors.black),
                              ),
                            ),
                            style: const TextStyle(color: Colors.black),
                            cursorColor: Colors.black,
                            cursorHeight: 20,
                            validator: (value) {
                              if (value!.isEmpty) {
                                return 'Ce champ est obligatoire';
                              }
                              if (value != passwordController.text) {
                                return "Le mot de passe n'est pas identique";
                              }
                              return null;
                            }),
                      ),
                      const SizedBox(height: 20),
                      Container(
                        width: 150,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10)),
                              primary: Colors.blue[900],
                              elevation: 5),
                          onPressed: () async {
                            isload = true;
                            setState(() {});
                            if (formKey.currentState!.validate()) {
                              var password = passwordController.text;
                              var session =
                                  await SharedPreferences.getInstance();
                              var email =
                                  session.getString("emailRecuperation")!;
                              var og = await getOrganisateurByEmail(email);
                              await updateOrganisateur(og["id_O"], og["nom"],
                                  og["prenom"], og["email"], password);
                              print(password + email);
                              Fluttertoast.showToast(
                                  msg: "Password modifié avec succès");

                              Navigator.of(context)
                                  .pushReplacement(MaterialPageRoute(
                                builder: (ctx) {
                                  return const Connexion();
                                },
                              ));
                            }

                            isload = false;
                            setState(() {});
                          },
                          child: isload
                              ? const SizedBox(
                                  height: 20,
                                  width: 20,
                                  child: CircularProgressIndicator(
                                    color: Color.fromARGB(255, 255, 255, 255),
                                  ))
                              : const Text(
                                  "Envoyer",
                                  style: TextStyle(color: Colors.white),
                                ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          )),
    );
  }
}
