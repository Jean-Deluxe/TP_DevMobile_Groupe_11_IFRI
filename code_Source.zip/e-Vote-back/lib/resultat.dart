import 'dart:ui';

import 'package:e_vote/fileBack/api_DB.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:e_vote/partclass/cand.dart';
import 'package:e_vote/partclass/pourc.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Resultat extends StatefulWidget {
  const Resultat({Key? key}) : super(key: key);

  @override
  State<Resultat> createState() => _ResultatState();
}

class _ResultatState extends State<Resultat> {
  bool paus = true;
  dynamic listes;
  var code;
  int eff = 0;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    load();
  }

  void load() {
    SharedPreferences.getInstance().then((session) {
      code = session.getString("code");
      print("=> $code");
      getCandidatToElection(code).then((candidats) {
        if (session.getString("type") == "Public") {
          getNbrElecteurToElectionPublic(code).then((nbr) {
            setState(() {
              eff = int.parse(nbr["nbr"].toString());
              listes = candidats;
              paus = false;
            });
          });
        } else {
          getNbrElecteurToElectionPrive(code).then((nbr) {
            setState(() {
              eff = int.parse(nbr["nbr"].toString());
              listes = candidats;
              paus = false;
            });
          });
        }
      });
    });
  }

  List<Widget> loadingListe() {
    List<Widget> candidats = <Widget>[];
    paus
        ? candidats.add(const CircularProgressIndicator(
            color: Colors.red,
          ))
        : null;
    if (candidats.isEmpty) {
      for (var candidat in listes) {
        print(eff != 0 ? (int.parse(candidat["voix"]) * 100) / eff : "0");

        candidats.add(
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 10),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
              ),
              height: MediaQuery.of(context).size.height * 0.28,
              width: MediaQuery.of(context).size.width * 0.38,
              child: ElevatedButton(
                onPressed: () {},
                style: ElevatedButton.styleFrom(
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                        side: const BorderSide(
                            color: Color(0xFF07FF66),
                            style: BorderStyle.solid,
                            width: 3)),
                    elevation: 25,
                    shadowColor: Color.fromARGB(255, 73, 12, 12)),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(90),
                      child: CircleAvatar(
                        radius: 50,
                        child: Center(
                          child: Image.asset(
                            "assets/profill.png",
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 4,
                    ),
                    Text(
                      candidat["nom"],
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(
                      height: 4,
                    ),
                    Text(
                      candidat["prenom"],
                      style: const TextStyle(),
                    ),
                    const SizedBox(
                      height: 4,
                    ),
                    Container(
                      color: Color.fromARGB(255, 122, 61, 4),
                      width: MediaQuery.of(context).size.width * 0.1,
                      height: MediaQuery.of(context).size.height * 0.03,
                      child: Text(
                        "${(eff != 0) ? ((int.parse(candidat["voix"]) * 100) / eff).toString() : "0"}"
                        "%",
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      }
    }
    return candidats;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Resultat du vote",
          style: TextStyle(
              color: Color(0xFF2F80F7),
              fontSize: 30,
              fontWeight: FontWeight.bold),
          textAlign: TextAlign.center,
        ),
        centerTitle: true,
        backgroundColor: const Color(0xFFE4E8E9),
        foregroundColor: Color(0xFF2F80F7),
        elevation: 0,
      ),
      body: Container(
        color: const Color(0xFFE4E8E9),
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(vertical: 50),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: loadingListe(),
          ),
        ),
      ),
    );
  }
}
