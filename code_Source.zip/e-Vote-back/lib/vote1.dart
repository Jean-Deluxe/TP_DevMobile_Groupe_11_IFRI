import 'package:e_vote/acceuil.dart';
import 'package:flutter/material.dart';

import 'main.dart';

class vote1 extends StatefulWidget {
  const vote1({Key? key}) : super(key: key);

  @override
  State<vote1> createState() => _vote1State();
}

class _vote1State extends State<vote1> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
          height: MediaQuery.of(context).size.height,
          color: Colors.white.withBlue(200),
          padding: const EdgeInsets.all(20),
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Row(
                  children: [
                    GestureDetector(
                      child: const Icon(Icons.arrow_back),
                      onTap: () => Navigator.push(context,
                          MaterialPageRoute(builder: (e) => const Acceuil())),
                    ),
                    const Padding(
                      padding: EdgeInsets.only(left: 70),
                      child: Text(
                        "Vote MissB",
                        style: TextStyle(
                          color: Color(0xFF2F80F7),
                          fontSize: 30,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
                const Padding(
                  padding: EdgeInsets.only(top: 25),
                  child: Text("Description vote",
                      style:
                          TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
                ),
                Container(
                  padding:
                      const EdgeInsets.symmetric(vertical: 20, horizontal: 10),
                  margin: const EdgeInsets.symmetric(vertical: 15),
                  width: MediaQuery.of(context).size.width,
                  decoration: const BoxDecoration(
                      color: Colors.white,
                      borderRadius:
                          BorderRadius.all(const Radius.circular(10))),
                  child: const Text(
                    "lorerhdkud eoirhgoie virtoie  reiotpoiuerp r pterlorerhdkud eoirhgoie virtoie  reiotpoiuerp r pterlorerhdkud eoirhgoie virtoie  reiotpoiuerp r pterlorerhdkud eoirhgoie virtoie  reiotpoiuerp r pter  ipoer oereto ipoerier eoiioern riguorgpojneporjtpoe eroptjpeojpoertjpeor eptoepoe erpotpoet vpiopetpo",
                    style: TextStyle(fontWeight: FontWeight.w500),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 15),
                  child: ElevatedButton(
                    onPressed: () {},
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(horizontal: 35),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30.0),
                      ),
                      primary: const Color(0xFF2F80F7),
                    ),
                    child: const Text(
                      "Passer au vote",
                      style: TextStyle(fontSize: 16),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  child: ElevatedButton(
                    onPressed: () {},
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(horizontal: 35),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30.0),
                      ),
                      primary: const Color(0xFF2F80F7),
                    ),
                    child: const Text(
                      "Détails vote",
                      style: TextStyle(fontSize: 16),
                    ),
                  ),
                ),
              ],
            ),
          )),
    );
  }
}
