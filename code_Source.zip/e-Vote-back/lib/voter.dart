import 'package:e_vote/attent.dart';
import 'package:e_vote/cloturer.dart';
import 'package:e_vote/detail.dart';
import 'package:e_vote/fileBack/api_DB.dart';
import 'package:e_vote/fileBack/stringToDateTime.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:e_vote/listCandidat.dart';
import 'package:e_vote/confirmationVote.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Voter extends StatefulWidget {
  const Voter({Key? key}) : super(key: key);

  @override
  State<Voter> createState() => _VoterState();
}

class _VoterState extends State<Voter> {
  final codeController = TextEditingController();
  final idController = TextEditingController();
  final formKey = GlobalKey<FormState>();
  var election;
  var brut;
  var tmp1;
  var tmp2;
  String msg = "";
  bool checkVote = false;
  bool checkElecteur = false;
  bool isload = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text(
            "eVote",
            style: TextStyle(
                color: Color(0xFF0D47A1),
                fontSize: 30,
                fontWeight: FontWeight.bold),
            textAlign: TextAlign.center,
          ),
          centerTitle: true,
          backgroundColor: const Color(0xFFE4E8E9),
          foregroundColor: const Color(0xFF0D47A1),
          elevation: 0,
        ),
        body: SingleChildScrollView(
          child: Container(
            //possss
            padding: const EdgeInsets.symmetric(vertical: 80),
            height: MediaQuery.of(context).size.height,
            width: MediaQuery.of(context).size.width,
            decoration: const BoxDecoration(color: Color(0xFFE4E8E9)),
            child: SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Form(
                    key: formKey,
                    child: Column(
                      children: <Widget>[
                        Container(
                          width: MediaQuery.of(context).size.width,
                          margin: const EdgeInsets.symmetric(horizontal: 10),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Flexible(
                                flex: 3,
                                child: Text(
                                  "Code de vote:",
                                  style: TextStyle(
                                      fontSize: 22,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black),
                                ),
                              ),
                              Flexible(
                                flex: 5,
                                child: Container(
                                  padding: const EdgeInsets.all(5),
                                  decoration: BoxDecoration(
                                      color: Colors.white,
                                      boxShadow: const [
                                        BoxShadow(
                                            color: Colors.black12,
                                            offset: Offset(0, 5),
                                            blurRadius: 10,
                                            spreadRadius: 2)
                                      ],
                                      borderRadius: BorderRadius.circular(20)),
                                  child: TextFormField(
                                      //obscureText: true,
                                      controller: codeController,
                                      keyboardType: TextInputType.text,
                                      textAlign: TextAlign.start,
                                      decoration: const InputDecoration(
                                          fillColor: Color(0xFFFFFFFF),
                                          filled: true,
                                          border: InputBorder.none),
                                      style: const TextStyle(
                                          height: 1, color: Colors.black),
                                      cursorColor: Colors.black,
                                      validator: (value) {
                                        if (value == null || value == "") {
                                          return "Ce champ est obligatoire";
                                        }
                                        if (checkVote) {
                                          return "Ce code saisir n'exist pas";
                                        }
                                        return null;
                                      }),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 50),
                        Container(
                          width: MediaQuery.of(context).size.width,
                          margin: const EdgeInsets.symmetric(horizontal: 10),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Flexible(
                                flex: 3,
                                child: Text(
                                  "Identifiant:",
                                  style: TextStyle(
                                      fontSize: 22,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black),
                                ),
                              ),
                              Flexible(
                                flex: 5,
                                child: Container(
                                  padding: const EdgeInsets.all(5),
                                  decoration: BoxDecoration(
                                      color: Colors.white,
                                      boxShadow: const [
                                        BoxShadow(
                                            color: Colors.black12,
                                            offset: Offset(0, 5),
                                            blurRadius: 10,
                                            spreadRadius: 2)
                                      ],
                                      borderRadius: BorderRadius.circular(20)),
                                  child: TextFormField(
                                      controller: idController,
                                      keyboardType: TextInputType.text,
                                      textAlign: TextAlign.start,
                                      decoration: const InputDecoration(
                                        fillColor: Color(0xFFFFFFFF),
                                        filled: true,
                                        border: InputBorder.none,
                                      ),
                                      style: const TextStyle(
                                          height: 1, color: Colors.black),
                                      cursorColor: Colors.black,
                                      validator: (value) {
                                        if (value == null || value == "") {
                                          return "Ce champ est obligatoire";
                                        }
                                        if (!checkElecteur) {
                                          return msg;
                                        }
                                        return null;
                                      }),
                                ),
                              ),
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                  const SizedBox(
                    height: 100,
                  ),
                  Container(
                    width: 150,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10)),
                          primary: Colors.blue[900],
                          elevation: 5),
                      onPressed: () {
                        isload = true;
                        setState(() {});

                        //Récuperation de l'election
                        getElection(codeController.text).then((election) {
                          print("hello");
                          if (election.runtimeType != bool) {
                            var end = stringToDateTime(election["end"]);
                            var begin = stringToDateTime(election["begin"]);
                            print(DateTime.now().isAfter(begin));

                            if (DateTime.now().isAfter(begin)) {
                              if (election.runtimeType != bool) {
                                if (election["type"] == "Privé") {
                                  //Recuperation de la liste des elections chosi par l'organisateur
                                  getElecteurByElection(election["code"])
                                      .then((electeurs) {
                                    print("j'y suis");
                                    List<dynamic> lists =
                                        List<dynamic>.from(electeurs);
                                    print(
                                        lists); //Verification de l'indentifiant secret
                                    for (var i in lists) {
                                      if (i["id_epv"] == idController.text) {
                                        checkElecteur = true;
                                        SharedPreferences.getInstance()
                                            .then((value) {
                                          value.setString(
                                              'email', idController.text);
                                          value.setString(
                                              'code', election["code"]);
                                          value.setString(
                                              'type', election["type"]);
                                          value.setString(
                                              "desc", election["description"]);
                                          value.setString(
                                              "nom", election["nom"]);
                                          value.setString(
                                              "end", election["end"]);
                                        });
                                        print("hfdsss");
                                        Navigator.of(context).push(
                                          MaterialPageRoute(
                                            builder: (ctx) {
                                              return const Detail();
                                            },
                                          ),
                                        );
                                        break;
                                      } else {
                                        checkElecteur = false;
                                        msg =
                                            "vous n'est pas invité a ce élection";
                                      }
                                    }
                                  });
                                } else {
                                  //vote public
                                  //Verification de l'email
                                  if (!idController.text.contains("@")) {
                                    checkElecteur = false;
                                    msg = "Merci de saisir votre email correct";
                                  } else {
                                    checkElecteur = true;
                                    SharedPreferences.getInstance()
                                        .then((value) {
                                      value.setString(
                                          'email', idController.text);
                                      value.setString('code', election["code"]);
                                      value.setString('type', election["type"]);
                                      value.setString(
                                          "desc", election["description"]);
                                      value.setString("nom", election["nom"]);
                                      value.setString("end", election["end"]);
                                    });

                                    /*getElecteurToElecctionPublic(
                                              idController.text)
                                          .then((value) {
                                        print(value);
                                        if (value.runtimeType == bool) {
                                          setElecteurPublic(idController.text)
                                              .then((value) {
                                            setMarqueElecteurPublic(
                                                election["code"],
                                                value["id_epb"].toString());
                                          });
                                        }
                                      });*/
                                  }
                                }
                                checkVote = false;
                              } else {
                                checkVote = true;
                                setState(() {});
                              }
                              if (formKey.currentState!.validate()) {
                                Navigator.of(context).push(
                                  MaterialPageRoute(
                                    builder: (ctx) {
                                      return const Detail();
                                    },
                                  ),
                                );
                              }
                            } else {
                              SharedPreferences.getInstance().then((value) {
                                value.setString("begin", begin.toString());
                              });

                              Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (ctx) {
                                    return const Attent();
                                  },
                                ),
                              );
                            }
                          } else {
                            checkVote = true;
                            formKey.currentState!.validate();
                          }
                          isload = false;
                          setState(() {});
                        });
                      },
                      child: isload
                          ? const SizedBox(
                              height: 20,
                              width: 20,
                              child: CircularProgressIndicator(
                                color: Color.fromARGB(255, 255, 255, 255),
                              ))
                          : const Text(
                              "Valider",
                              style: TextStyle(color: Colors.white),
                            ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ));
  }
}
